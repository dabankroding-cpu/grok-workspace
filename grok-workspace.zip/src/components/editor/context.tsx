import { createContext, useContext, type ReactNode, type RefObject } from "react";
import type { EditorState } from "@/lib/editor-types";
import type { Account } from "@/lib/plans";
import type { Project } from "@/lib/project-types";

export type EditorApi = {
  project: Project;
  editor: EditorState;
  updateEditor: (fn: (editor: EditorState) => EditorState) => void;
  title: string;
  setTitle: (title: string) => void;
  templateId: string;
  setTemplate: (id: string) => void;
  status: string;
  setStatus: (status: string) => void;
  media: { durationSec: number; width: number; height: number; sourceName: string };
  videoUrl: string | null;
  videoFile: Blob | null;
  videoRef: RefObject<HTMLVideoElement | null>;
  canvasRef: RefObject<HTMLCanvasElement | null>;
  musicRef: RefObject<HTMLAudioElement | null>;
  musicUrl: string | null;
  attachVideo: (file: File) => Promise<void>;
  attachMusic: (file: File) => Promise<void>;
  clearMusic: () => Promise<void>;
  account: Account;
  reloadAccount: () => void;
  busy: string | null;
  setBusy: (busy: string | null) => void;
  saveState: "saved" | "saving" | "error";
  exportingRef: RefObject<boolean>;
};

const EditorContext = createContext<EditorApi | null>(null);

export function EditorProvider({ value, children }: { value: EditorApi; children: ReactNode }) {
  return <EditorContext.Provider value={value}>{children}</EditorContext.Provider>;
}

export function useEditor() {
  const value = useContext(EditorContext);
  if (!value) throw new Error("Editor is not ready.");
  return value;
}
