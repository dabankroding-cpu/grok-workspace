import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Logo } from "@/components/logo";
import { buttonClass } from "@/components/ui/button";

export function SiteHeader() {
  const { user, isPending } = useCurrentUserState();
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4">
        <Logo />
        <nav className="hidden items-center gap-6 text-sm text-muted md:flex">
          <a href="/#tools" className="hover:text-fg">
            Tools
          </a>
          <Link to="/templates" className="hover:text-fg">
            Templates
          </Link>
          <Link to="/pricing" className="hover:text-fg">
            Pricing
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          {isPending ? <span className="h-10 w-28 rounded-md bg-surface-2 motion-safe:animate-pulse" /> : null}
          {!isPending && user ? (
            <>
              <Link to="/dashboard" className={buttonClass({ size: "sm" })}>
                Open studio
              </Link>
              <UserButton />
            </>
          ) : null}
          {!isPending && !user ? (
            <Link to="/login" className={buttonClass({ size: "sm" })}>
              Sign in
            </Link>
          ) : null}
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>ClipForge AI. Video files stay in this browser. Project settings stay on your account.</p>
        <div className="flex gap-4">
          <Link to="/templates" className="hover:text-fg">
            Templates
          </Link>
          <Link to="/pricing" className="hover:text-fg">
            Pricing
          </Link>
        </div>
      </div>
    </footer>
  );
}
