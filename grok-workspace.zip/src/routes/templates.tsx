import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { Badge } from "@/components/ui/badge";
import { buttonClass } from "@/components/ui/button";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { TEMPLATES } from "@/lib/templates-data";
import { useAccount } from "@/lib/use-account";

export const Route = createFileRoute("/templates")({
  component: TemplatesPage,
});

function TemplatesPage() {
  const { user, isPending } = useCurrentUserState();
  const { account, loading } = useAccount(user?.id);
  return (
    <div className="min-h-dvh bg-bg">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-4 py-12">
        <h1 className="font-display text-4xl font-semibold tracking-tight">Templates</h1>
        <p className="mt-3 max-w-2xl text-muted">
          A template is a grade, caption style, crop, and effect pattern. Applying one replaces effects. It does not invent footage.
        </p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {TEMPLATES.map((template) => {
            const unlocked = !user || !account ? template.tier === "free" : account.templateIds.includes(template.id);
            const next = `/dashboard?template=${template.id}`;
            return (
              <article key={template.id} className="rounded-2xl border border-line bg-surface p-4">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="font-display text-2xl font-semibold">{template.name}</h2>
                  <Badge tone={template.tier === "free" ? "accent" : "primary"}>{template.tier === "free" ? "Free" : "Pro trial"}</Badge>
                </div>
                <p className="mt-3 text-sm text-muted">{template.blurb}</p>
                <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <dt className="text-muted">Grade</dt>
                    <dd className="capitalize">{template.grade}</dd>
                  </div>
                  <div>
                    <dt className="text-muted">Type</dt>
                    <dd className="capitalize">{template.captionStyle.font}</dd>
                  </div>
                </dl>
                <div className="mt-5">
                  {isPending || (user && loading) ? (
                    <span className="inline-block h-10 w-36 rounded-md bg-surface-2 motion-safe:animate-pulse" />
                  ) : user && unlocked ? (
                    <Link to="/dashboard" search={{ template: template.id }} className={buttonClass({ size: "sm" })}>
                      Use for next upload
                    </Link>
                  ) : user ? (
                    <Link to="/pricing" className={buttonClass({ variant: "secondary", size: "sm" })}>
                      Unlock with trial
                    </Link>
                  ) : (
                    <Link to="/login" search={{ next }} className={buttonClass({ size: "sm" })}>
                      Sign in to use
                    </Link>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
