import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/shell";
import { Badge } from "@/components/ui/badge";
import { buttonClass } from "@/components/ui/button";
import * as AlertDialog from "@radix-ui/react-alert-dialog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { createProjectFromFile } from "@/lib/create-project";
import { deleteProject, listProjects } from "@/lib/projects.server";
import type { ProjectSummary } from "@/lib/project-types";
import { templateById } from "@/lib/templates-data";
import { useAccount } from "@/lib/use-account";
import { deleteBlob, musicKey, videoKey } from "@/lib/video-db";
import { errorText, formatTime } from "@/lib/utils";

export const Route = createFileRoute("/dashboard")({
  validateSearch: (search: Record<string, unknown>): { template?: string } => {
    if (typeof search.template !== "string" || !search.template) return {};
    return { template: search.template.slice(0, 40) };
  },
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <AppShell>
      <Dashboard />
    </AppShell>
  );
}

function Dashboard() {
  const search = Route.useSearch();
  const { user } = useCurrentUserState();
  const { account, loading, error, reload } = useAccount(user?.id);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [listError, setListError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  function refresh() {
    listProjects()
      .then(setProjects)
      .catch((err: unknown) => setListError(errorText(err, "Could not load projects.")));
  }

  useEffect(() => {
    if (!user?.id) return;
    refresh();
  }, [user?.id]);

  useEffect(() => {
    if (!account || !search.template) return;
    if (!account.templateIds.includes(search.template)) {
      toast.error("That template needs the Pro trial. New uploads will use Cinematic.");
    }
  }, [account, search.template]);

  const chosen =
    account && search.template && account.templateIds.includes(search.template) ? search.template : "cinematic";

  async function onFile(file: File) {
    setPending(true);
    try {
      const result = await createProjectFromFile(file, chosen);
      if (result.warning) toast.error(result.warning);
      else toast.success("Project created. The video is stored on this device.");
      window.location.assign(`/editor/${result.project.id}`);
    } catch (err) {
      toast.error(errorText(err, "Could not create the project."));
      setPending(false);
    }
  }

  async function remove(id: string) {
    try {
      await deleteProject({ data: id });
      await Promise.all([deleteBlob(videoKey(id)), deleteBlob(musicKey(id))]).catch(() => undefined);
      toast.success("Project deleted.");
      refresh();
      reload();
    } catch (err) {
      toast.error(errorText(err, "Could not delete the project."));
    }
  }

  const name = account?.displayName || user?.displayName || "there";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Projects</h1>
          <p className="mt-1 text-sm text-muted">Hello, {name}.</p>
        </div>
        <label className={buttonClass({ className: pending ? "opacity-50" : "" })}>
          {pending ? "Uploading…" : "Upload video"}
          <input
            className="sr-only"
            type="file"
            accept="video/mp4,video/webm,video/quicktime"
            disabled={pending}
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (file) void onFile(file);
            }}
          />
        </label>
      </div>

      {error || listError ? <p className="text-sm text-danger">{error || listError}</p> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <Meter label="Projects" value={account?.projectCount ?? 0} max={account?.projectLimit ?? 0} loading={loading} />
        <Meter label="AI calls this month" value={account?.aiCallsMonth ?? 0} max={account?.aiLimit ?? 0} loading={loading} />
        <div className="rounded-2xl border border-line bg-surface p-4">
          <p className="text-sm text-muted">Plan</p>
          <p className="mt-2 font-display text-2xl font-semibold">{account?.plan === "trial" ? "Pro trial" : "Free"}</p>
          <Link to="/pricing" className="mt-2 inline-block text-sm text-accent-bright">
            Compare limits
          </Link>
        </div>
      </div>

      <p className="text-sm text-muted">
        New uploads use the {templateById(chosen).name} template. Video bytes stay in this browser. The account stores the cut, not the file.
      </p>

      {!projects.length ? (
        <div className="rounded-2xl border border-dashed border-line px-4 py-12 text-center">
          <p className="font-display text-xl font-semibold">No projects yet</p>
          <p className="mt-2 text-sm text-muted">Upload an MP4 or WebM under 8 minutes.</p>
        </div>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2">
          {projects.map((project) => (
            <li key={project.id} className="rounded-2xl border border-line bg-surface p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <Link to="/editor/$projectId" params={{ projectId: project.id }} className="font-display text-xl font-semibold hover:text-accent-bright">
                    {project.title}
                  </Link>
                  <p className="mt-1 text-sm text-muted">
                    {formatTime(project.durationSec)} · {templateById(project.templateId).name}
                  </p>
                </div>
                <Badge tone={project.status === "exported" ? "ok" : "neutral"}>{project.status}</Badge>
              </div>
              <p className="mt-3 text-sm tabular-nums text-muted">
                {project.clipCount} clips · {project.captionCount} captions
              </p>
              <div className="mt-4 flex gap-2">
                <Link to="/editor/$projectId" params={{ projectId: project.id }} className={buttonClass({ size: "sm" })}>
                  Edit
                </Link>
                <DeleteProject onConfirm={() => void remove(project.id)} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Meter({ label, value, max, loading }: { label: string; value: number; max: number; loading: boolean }) {
  const pct = max <= 0 ? 0 : Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="text-muted">{label}</span>
        <span className="tabular-nums">{loading ? "…" : `${value}/${max}`}</span>
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function DeleteProject({ onConfirm }: { onConfirm: () => void }) {
  return (
    <AlertDialog.Root>
      <AlertDialog.Trigger className={buttonClass({ variant: "danger", size: "sm" })}>Delete</AlertDialog.Trigger>
      <AlertDialog.Portal>
        <AlertDialog.Overlay className="fixed inset-0 z-40 bg-bg/80" />
        <AlertDialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,24rem)] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-line bg-surface p-4">
          <AlertDialog.Title className="font-display text-lg font-semibold">Delete this project?</AlertDialog.Title>
          <AlertDialog.Description className="mt-2 text-sm text-muted">
            The cut is removed from your account. The video stored in this browser is removed too.
          </AlertDialog.Description>
          <div className="mt-4 flex justify-end gap-2">
            <AlertDialog.Cancel className={buttonClass({ variant: "ghost", size: "sm" })}>Cancel</AlertDialog.Cancel>
            <AlertDialog.Action className={buttonClass({ variant: "danger", size: "sm" })} onClick={onConfirm}>
              Delete
            </AlertDialog.Action>
          </div>
        </AlertDialog.Content>
      </AlertDialog.Portal>
    </AlertDialog.Root>
  );
}
