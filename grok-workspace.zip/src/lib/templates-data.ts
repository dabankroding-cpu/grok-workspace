import {
  emptyEditor,
  type CaptionStyle,
  type EditorState,
  type Effect,
  type Grade,
} from "@/lib/editor-types";
import { round2 } from "@/lib/utils";

export type TemplatePattern = "zoom-slow" | "zoom-punch" | "shake" | "anime" | "phonk";

export type TemplateDef = {
  id: string;
  name: string;
  blurb: string;
  tier: "free" | "pro";
  grade: Grade;
  crop: EditorState["crop"];
  pattern: TemplatePattern;
  captionStyle: CaptionStyle;
};

export const TEMPLATES: TemplateDef[] = [
  {
    id: "cinematic",
    name: "Cinematic",
    blurb: "Slow push-in, quieter color, captions sitting low.",
    tier: "free",
    grade: "cinematic",
    crop: "center",
    pattern: "zoom-slow",
    captionStyle: { font: "syne", color: "paper", effect: "none", size: "md", position: "bottom" },
  },
  {
    id: "gaming",
    name: "Gaming",
    blurb: "Hard punch-zooms on the loudest hits and centered type.",
    tier: "free",
    grade: "gaming",
    crop: "center",
    pattern: "zoom-punch",
    captionStyle: { font: "manrope", color: "paper", effect: "pop", size: "lg", position: "center" },
  },
  {
    id: "nba",
    name: "NBA",
    blurb: "Impact shakes on energy spikes, outlined captions.",
    tier: "pro",
    grade: "nba",
    crop: "center",
    pattern: "shake",
    captionStyle: { font: "manrope", color: "paper", effect: "outline", size: "lg", position: "bottom" },
  },
  {
    id: "anime",
    name: "Anime",
    blurb: "Short zooms, lifted saturation, pop-in lines.",
    tier: "pro",
    grade: "anime",
    crop: "center",
    pattern: "anime",
    captionStyle: { font: "syne", color: "violet", effect: "pop", size: "md", position: "bottom" },
  },
  {
    id: "phonk",
    name: "Phonk",
    blurb: "Dark grade, shakes, and a white flash on the hits.",
    tier: "pro",
    grade: "phonk",
    crop: "center",
    pattern: "phonk",
    captionStyle: { font: "mono", color: "paper", effect: "outline", size: "md", position: "center" },
  },
];

export function templateById(id: string) {
  return TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0];
}

export function applyTemplate(state: EditorState, templateId: string, duration: number): EditorState {
  const template = TEMPLATES.find((t) => t.id === templateId);
  if (!template) return state;
  return {
    ...state,
    grade: template.grade,
    crop: template.crop,
    captionStyle: { ...template.captionStyle },
    effects: patternFor(template.pattern, duration, state.analysis?.peaks ?? []),
  };
}

export function initialEditor(templateId: string, duration: number) {
  return applyTemplate(emptyEditor(), templateId, duration);
}

function patternFor(
  pattern: TemplatePattern,
  duration: number,
  peaks: { t: number; energy: number }[],
): Effect[] {
  const safeDuration = Math.max(0.4, duration);
  const top = [...peaks].sort((a, b) => b.energy - a.energy).slice(0, 4);
  top.sort((a, b) => a.t - b.t);
  const anchors = top.length ? top.map((p) => p.t) : [Math.min(0.4, safeDuration * 0.1)];

  if (pattern === "zoom-slow") {
    return [
      {
        id: crypto.randomUUID(),
        type: "zoom",
        start: 0,
        end: round2(Math.min(safeDuration, 8)),
        intensity: 0.55,
      },
    ];
  }

  if (pattern === "zoom-punch" || pattern === "anime") {
    const len = pattern === "anime" ? 0.7 : 0.45;
    const intensity = pattern === "anime" ? 0.45 : 0.9;
    return anchors.map((t) => ({
      id: crypto.randomUUID(),
      type: "zoom" as const,
      start: round2(Math.min(t, safeDuration)),
      end: round2(Math.min(safeDuration, t + len)),
      intensity,
    }));
  }

  if (pattern === "shake") {
    return anchors.map((t) => ({
      id: crypto.randomUUID(),
      type: "shake" as const,
      start: round2(Math.max(0, t - 0.05)),
      end: round2(Math.min(safeDuration, t + 0.35)),
      intensity: 0.8,
    }));
  }

  return anchors.flatMap((t) => [
    {
      id: crypto.randomUUID(),
      type: "shake" as const,
      start: round2(t),
      end: round2(Math.min(safeDuration, t + 0.4)),
      intensity: 0.85,
    },
    {
      id: crypto.randomUUID(),
      type: "flash" as const,
      start: round2(t),
      end: round2(Math.min(safeDuration, t + 0.12)),
      intensity: 0.55,
    },
  ]);
}
