import { useEffect, useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { toast } from "sonner";
import { useEditor } from "@/components/editor/context";
import { Button } from "@/components/ui/button";
import { renderFrame } from "@/lib/render-frame";
import { formatTime } from "@/lib/utils";

export function Stage() {
  const api = useEditor();
  const editorRef = useRef(api.editor);
  editorRef.current = api.editor;
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const duration = api.media.durationSec;

  useEffect(() => {
    const video = api.videoRef.current;
    if (!video) return;
    if (api.videoUrl) {
      video.src = api.videoUrl;
      video.load();
    } else {
      video.removeAttribute("src");
    }
  }, [api.videoRef, api.videoUrl]);

  useEffect(() => {
    let frame = 0;
    const tick = () => {
      const video = api.videoRef.current;
      const canvas = api.canvasRef.current;
      if (video && canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) renderFrame(ctx, video, editorRef.current, video.currentTime || 0);
        setTime(video.currentTime || 0);
        setPlaying(!video.paused && !video.ended);
        const clip = editorRef.current.clips.find((item) => item.id === editorRef.current.activeClipId);
        if (!api.exportingRef.current && clip && !video.paused && video.currentTime >= clip.end) {
          video.pause();
          api.musicRef.current?.pause();
        }
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [api.exportingRef, api.musicRef, api.videoRef, api.canvasRef]);

  async function toggle() {
    const video = api.videoRef.current;
    if (!video || !api.videoUrl) return;
    if (!video.paused) {
      video.pause();
      api.musicRef.current?.pause();
      return;
    }
    const clip = api.editor.clips.find((item) => item.id === api.editor.activeClipId);
    if (clip && (video.currentTime < clip.start || video.currentTime >= clip.end - 0.05)) {
      video.currentTime = clip.start;
    }
    const music = api.musicRef.current;
    if (music && api.musicUrl) {
      music.currentTime = 0;
      void music.play().catch(() => undefined);
    }
    try {
      await video.play();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Playback was blocked.";
      throw new Error(message);
    }
  }

  const toggleRef = useRef(toggle);
  toggleRef.current = toggle;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const tag = target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (event.code !== "Space") return;
      event.preventDefault();
      void toggleRef.current().catch(() => undefined);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function seek(next: number) {
    const video = api.videoRef.current;
    if (!video) return;
    video.currentTime = Math.min(duration, Math.max(0, next));
  }

  const peaks = api.editor.analysis?.peaks ?? [];
  const maxEnergy = Math.max(0.0001, ...peaks.map((peak) => peak.energy));

  return (
    <section className="rounded-2xl border border-line bg-surface p-4">
      <div className="relative mx-auto w-full max-w-sm overflow-hidden rounded-xl bg-bg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_30%,transparent)]">
        <video ref={api.videoRef} className="absolute inset-0 size-full opacity-0" playsInline preload="auto" />
        <canvas ref={api.canvasRef} width={720} height={1280} className="relative block aspect-[9/16] w-full" />
        {!api.videoUrl ? (
          <div className="absolute inset-0 grid place-items-center px-6 text-center">
            <p className="text-sm text-muted">Attach the video stored for this project to preview the 9:16 frame.</p>
          </div>
        ) : null}
      </div>
      <div className="mt-4 flex items-center gap-3">
        <Button size="sm" variant="secondary" aria-label={playing ? "Pause" : "Play"} onClick={() => void toggle().catch(() => undefined)} disabled={!api.videoUrl || Boolean(api.busy)}>
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
          {playing ? "Pause" : "Play"}
        </Button>
        <p className="font-mono text-sm tabular-nums text-muted">
          {formatTime(time)} / {formatTime(duration)}
        </p>
      </div>
      <label className="mt-3 block text-xs text-muted">
        Scrub
        <input
          className="mt-2"
          type="range"
          min={0}
          max={Math.max(duration, 0.1)}
          step={0.01}
          value={Math.min(time, duration || 0)}
          onChange={(event) => seek(Number(event.target.value))}
          disabled={!api.videoUrl}
        />
      </label>
      <div className="mt-4">
        <svg
          viewBox={`0 0 ${Math.max(duration, 1)} 36`}
          className="h-16 w-full rounded-md bg-bg"
          role="img"
          aria-label="Soundtrack energy"
          onClick={(event) => {
            const rect = event.currentTarget.getBoundingClientRect();
            const ratio = (event.clientX - rect.left) / rect.width;
            seek(ratio * duration);
          }}
        >
          {peaks.length ? (
            peaks.map((peak) => (
              <rect
                key={`${peak.t}`}
                x={peak.t}
                y={36 - (peak.energy / maxEnergy) * 32}
                width={Math.max(duration / peaks.length, 0.05)}
                height={(peak.energy / maxEnergy) * 32}
                className="fill-accent/80"
              />
            ))
          ) : null}
          {api.editor.clips.map((clip) => (
            <rect
              key={clip.id}
              x={clip.start}
              y="0"
              width={Math.max(0.05, clip.end - clip.start)}
              height="36"
              className={clip.id === api.editor.activeClipId ? "fill-primary/30" : "fill-primary/10"}
            />
          ))}
          <line x1={time} x2={time} y1="0" y2="36" className="stroke-fg" strokeWidth={Math.max(duration / 180, 0.04)} />
        </svg>
      </div>
      <label className="mt-4 block">
        <span className="text-sm text-muted">{api.videoUrl ? "Replace video on this device" : "Attach video"}</span>
        <input
          className="mt-2 block w-full text-sm"
          type="file"
          accept="video/mp4,video/webm,video/quicktime"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void api.attachVideo(file).catch((err: unknown) => {
              toast.error(err instanceof Error ? err.message : "Could not attach that video.");
            });
          }}
        />
      </label>
    </section>
  );
}
