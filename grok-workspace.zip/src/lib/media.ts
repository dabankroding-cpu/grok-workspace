import type { Caption, Clip } from "@/lib/editor-types";
import { round2 } from "@/lib/utils";

export type Peak = { t: number; energy: number };

export function probeVideo(file: File): Promise<{ duration: number; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.playsInline = true;
    video.src = url;
    video.onloadedmetadata = () => {
      const result = {
        duration: video.duration,
        width: video.videoWidth,
        height: video.videoHeight,
      };
      URL.revokeObjectURL(url);
      video.src = "";
      resolve(result);
    };
    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read that video. Use MP4 or WebM."));
    };
  });
}

export function assertUpload(file: File, meta: { duration: number; width: number; height: number }) {
  const looksVideo = file.type.startsWith("video/") || /\.(mp4|webm|mov|mkv)$/i.test(file.name);
  if (!looksVideo) throw new Error("Choose a video file (MP4 or WebM).");
  if (file.size > 120 * 1024 * 1024) throw new Error("Videos need to be under 120 MB.");
  if (!Number.isFinite(meta.duration) || meta.duration <= 0) {
    throw new Error("Could not read the video length.");
  }
  if (meta.duration > 8 * 60) throw new Error("Keep uploads under 8 minutes.");
  if (meta.width < 2 || meta.height < 2) throw new Error("Could not read the video dimensions.");
}

export async function audioEnergy(file: Blob, maxSec: number): Promise<Peak[]> {
  const ctx = new AudioContext();
  try {
    const bytes = await file.arrayBuffer();
    let buf: AudioBuffer;
    try {
      buf = await ctx.decodeAudioData(bytes.slice(0));
    } catch {
      throw new Error("This browser could not decode the audio track. Try MP4 with AAC audio.");
    }
    const channel = buf.getChannelData(0);
    const win = Math.max(1, Math.floor(buf.sampleRate * 0.25));
    const maxSamples = Math.min(channel.length, Math.floor(maxSec * buf.sampleRate));
    const peaks: Peak[] = [];
    for (let i = 0; i < maxSamples; i += win) {
      let sum = 0;
      const end = Math.min(maxSamples, i + win);
      for (let j = i; j < end; j += 1) sum += channel[j] * channel[j];
      const rms = Math.sqrt(sum / Math.max(1, end - i));
      peaks.push({ t: round2(i / buf.sampleRate), energy: round2(rms) });
    }
    return peaks;
  } finally {
    await ctx.close();
  }
}

export function downsamplePeaks(peaks: Peak[], max: number): Peak[] {
  if (peaks.length <= max) return peaks;
  const bucket = Math.ceil(peaks.length / max);
  const out: Peak[] = [];
  for (let i = 0; i < peaks.length; i += bucket) {
    const slice = peaks.slice(i, i + bucket);
    out.push(slice.reduce((best, peak) => (peak.energy > best.energy ? peak : best)));
  }
  return out;
}

export function clipsFromEnergy(peaks: Peak[], duration: number): Clip[] {
  if (duration <= 0) return [];
  const maxE = Math.max(...peaks.map((p) => p.energy), 0.0001);
  const ranked = [...peaks].sort((a, b) => b.energy - a.energy);
  const picked: Peak[] = [];
  for (const peak of ranked) {
    if (picked.length >= 5) break;
    if (peak.energy < maxE * 0.35 && picked.length > 0) break;
    if (picked.some((p) => Math.abs(p.t - peak.t) < 8)) continue;
    picked.push(peak);
  }
  picked.sort((a, b) => a.t - b.t);
  if (!picked.length) {
    const end = Math.min(duration, 12);
    return [
      {
        id: crypto.randomUUID(),
        start: 0,
        end: round2(Math.max(3, end)),
        title: "Opening",
        reason: "No strong loudness spikes, so this is the opening stretch of the file.",
        score: round2(maxE > 0 ? peaks[0]?.energy / maxE || 0 : 0),
        platform: "tiktok",
        source: "energy",
      },
    ];
  }
  const platforms: Clip["platform"][] = ["tiktok", "shorts", "reels"];
  return picked.map((peak, index) => {
    const start = Math.max(0, peak.t - 1.2);
    const end = Math.min(duration, Math.max(start + 4, peak.t + 8));
    return {
      id: crypto.randomUUID(),
      start: round2(start),
      end: round2(end),
      title: `Energy peak ${index + 1}`,
      reason: `Loudest nearby stretch. Measured RMS peaks at ${round2(peak.t)}s.`,
      score: round2(peak.energy / maxE),
      platform: platforms[index % platforms.length],
      source: "energy" as const,
    };
  });
}

export async function sampleFrames(file: Blob, times: number[]): Promise<{ t: number; dataUrl: string }[]> {
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.src = url;
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  try {
    await waitFor(video, "loadeddata");
    const canvas = document.createElement("canvas");
    const ratio = video.videoWidth > 0 ? video.videoHeight / video.videoWidth : 16 / 9;
    canvas.width = 320;
    canvas.height = Math.max(180, Math.min(420, Math.round(320 * ratio)));
    const ctx = canvas.getContext("2d");
    if (!ctx) return [];
    const frames: { t: number; dataUrl: string }[] = [];
    for (const time of times.slice(0, 3)) {
      const target = Math.min(Math.max(0, time), Math.max(0, (video.duration || time) - 0.05));
      if (Math.abs(video.currentTime - target) > 0.05) {
        video.currentTime = target;
        await waitFor(video, "seeked");
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.62);
      if (dataUrl.length < 180_000) frames.push({ t: round2(target), dataUrl });
    }
    return frames;
  } finally {
    URL.revokeObjectURL(url);
    video.src = "";
  }
}

export async function extractWav(file: Blob, start: number, end: number): Promise<Blob> {
  const length = end - start;
  if (length < 0.3) throw new Error("Pick a longer range to transcribe.");
  const ctx = new AudioContext();
  try {
    const bytes = await file.arrayBuffer();
    let buf: AudioBuffer;
    try {
      buf = await ctx.decodeAudioData(bytes.slice(0));
    } catch {
      throw new Error("This browser could not decode the audio track. Try MP4 with AAC audio.");
    }
    const offset = Math.min(Math.max(0, start), Math.max(0, buf.duration - 0.1));
    const slice = Math.min(length, Math.max(0.3, buf.duration - offset));
    const offline = new OfflineAudioContext(1, Math.ceil(slice * 16000), 16000);
    const source = offline.createBufferSource();
    source.buffer = buf;
    source.connect(offline.destination);
    source.start(0, offset, slice);
    const rendered = await offline.startRendering();
    return encodeWav(rendered);
  } finally {
    await ctx.close();
  }
}

export function captionsFromWords(
  words: { text: string; start: number; end: number }[],
  offset: number,
): Omit<Caption, "id">[] {
  const out: Omit<Caption, "id">[] = [];
  let bucket: { text: string; start: number; end: number }[] = [];
  const flush = () => {
    if (!bucket.length) return;
    const text = bucket
      .map((w) => w.text)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (text) {
      out.push({
        start: round2(offset + bucket[0].start),
        end: round2(Math.max(offset + bucket[0].start + 0.2, offset + bucket[bucket.length - 1].end)),
        text,
        words: bucket.map((w) => ({
          text: w.text,
          start: round2(offset + w.start),
          end: round2(offset + w.end),
        })),
        timing: "words",
      });
    }
    bucket = [];
  };
  for (const word of words) {
    bucket.push(word);
    const dur = word.end - bucket[0].start;
    if (bucket.length >= 5 || dur >= 2.2) flush();
  }
  flush();
  return out;
}

export function captionsEstimated(text: string, start: number, end: number): Omit<Caption, "id">[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length || end <= start) return [];
  const chunks: string[][] = [];
  for (let i = 0; i < words.length; i += 5) chunks.push(words.slice(i, i + 5));
  const span = end - start;
  return chunks.map((chunk, index) => {
    const a = start + (span * index) / chunks.length;
    const b = start + (span * (index + 1)) / chunks.length;
    return {
      start: round2(a),
      end: round2(Math.max(a + 0.2, b)),
      text: chunk.join(" "),
      words: [],
      timing: "estimated" as const,
    };
  });
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const value = String(reader.result ?? "");
      const index = value.indexOf(",");
      resolve(index >= 0 ? value.slice(index + 1) : value);
    };
    reader.onerror = () => reject(new Error("Could not read the audio slice."));
    reader.readAsDataURL(blob);
  });
}

function encodeWav(buffer: AudioBuffer): Blob {
  const samples = buffer.getChannelData(0);
  const bytes = new Uint8Array(44 + samples.length * 2);
  const view = new DataView(bytes.buffer);
  const write = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i += 1) view.setUint8(offset + i, text.charCodeAt(i));
  };
  write(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, samples.length * 2, true);
  let offset = 44;
  for (let i = 0; i < samples.length; i += 1) {
    const sample = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
    offset += 2;
  }
  return new Blob([bytes], { type: "audio/wav" });
}

function waitFor(target: EventTarget, event: string, ms = 8000) {
  return new Promise<void>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      target.removeEventListener(event, onEvent);
      reject(new Error("Timed out while reading the video."));
    }, ms);
    const onEvent = () => {
      window.clearTimeout(timer);
      resolve();
    };
    target.addEventListener(event, onEvent, { once: true });
  });
}
