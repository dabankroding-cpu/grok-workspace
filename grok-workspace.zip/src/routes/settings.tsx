import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PlanCards } from "@/components/plan-cards";
import { AppShell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { updateDisplayName } from "@/lib/projects.server";
import { useAccount } from "@/lib/use-account";
import { errorText } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <AppShell>
      <Settings />
    </AppShell>
  );
}

function Settings() {
  const { user } = useCurrentUserState();
  const { account, loading, error, reload, setAccount } = useAccount(user?.id);
  const [name, setName] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const value = name ?? account?.displayName ?? "";

  async function save() {
    setPending(true);
    try {
      const next = await updateDisplayName({ data: value });
      setAccount(next);
      setName(null);
      toast.success("Profile saved.");
    } catch (err) {
      toast.error(errorText(err, "Could not save."));
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-2 text-sm text-muted">{user?.primaryEmail}</p>
      </div>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <form
        className="max-w-md space-y-3 rounded-2xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          void save();
        }}
      >
        <Field label="Display name">
          <Input value={value} maxLength={40} disabled={loading} onChange={(event) => setName(event.target.value)} />
        </Field>
        <Button type="submit" disabled={pending || loading}>
          {pending ? "Saving…" : "Save profile"}
        </Button>
      </form>
      <section className="max-w-2xl space-y-3 text-sm text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">AI and files</h2>
        <p>
          Ranking and music search use Grok (`grok-4.5`). Captions use xAI speech-to-text (`grok-voice-transcribe-2.0`). The server reads `XAI_API_KEY` from the environment. Publishing this app injects that key. There is nothing to paste here.
        </p>
        <p>
          If AI is unavailable, the buttons say so. Energy peaks, manual caption lines, effects, templates you can access, and WebM export keep working because they run in the browser.
        </p>
        <p>Video and music files are stored in this browser only. Another device will ask you to attach the file again. Project settings sync with your account.</p>
      </section>
      <PlanCards account={account} loading={loading} signedIn onChanged={reload} />
    </div>
  );
}
