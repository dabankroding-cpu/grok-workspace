function pickMime() {
  if (typeof MediaRecorder === "undefined") return "";
  const types = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  return types.find((type) => MediaRecorder.isTypeSupported(type)) ?? "";
}

let audioCtx: AudioContext | null = null;
const wired = new WeakMap<HTMLMediaElement, MediaElementAudioSourceNode>();

function getAudioContext() {
  if (!audioCtx) audioCtx = new AudioContext();
  return audioCtx;
}

function mediaNode(el: HTMLMediaElement) {
  const ctx = getAudioContext();
  let node = wired.get(el);
  if (!node) {
    node = ctx.createMediaElementSource(el);
    node.connect(ctx.destination);
    wired.set(el, node);
  }
  return node;
}

export async function recordCanvas(options: {
  video: HTMLVideoElement;
  canvas: HTMLCanvasElement;
  start: number;
  end: number;
  music?: HTMLAudioElement | null;
  onProgress: (value: number) => void;
}): Promise<{ blob: Blob; mime: string; audio: boolean }> {
  const { video, canvas, music, onProgress } = options;
  const start = Math.max(0, options.start);
  const end = Math.max(start + 0.4, options.end);
  const mime = pickMime();
  if (!mime) throw new Error("This browser cannot record WebM. Use Chrome or Edge.");
  if (typeof canvas.captureStream !== "function") {
    throw new Error("This browser cannot capture the preview canvas.");
  }

  const ctx = getAudioContext();
  void ctx.resume();

  if (Math.abs(video.currentTime - start) > 0.08) {
    video.currentTime = start;
    await wait(video, "seeked");
  }

  const stream = canvas.captureStream(30);
  const dest = ctx.createMediaStreamDestination();
  const videoNode = mediaNode(video);
  videoNode.disconnect();
  videoNode.connect(ctx.destination);
  videoNode.connect(dest);

  let musicNode: MediaElementAudioSourceNode | null = null;
  let musicGain: GainNode | null = null;
  if (music) {
    musicNode = mediaNode(music);
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.38;
    musicNode.disconnect();
    musicNode.connect(musicGain);
    musicGain.connect(ctx.destination);
    musicGain.connect(dest);
    music.currentTime = 0;
  }

  for (const track of dest.stream.getAudioTracks()) stream.addTrack(track);
  const hasAudio = dest.stream.getAudioTracks().length > 0;

  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 2_800_000 });
  const chunks: Blob[] = [];

  const blob = await new Promise<Blob>((resolve, reject) => {
    recorder.ondataavailable = (event) => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onerror = () => reject(new Error("Recording failed."));
    recorder.onstop = () => resolve(new Blob(chunks, { type: mime }));

    const timer = window.setInterval(() => {
      const span = end - start;
      const progress = span > 0 ? (video.currentTime - start) / span : 1;
      onProgress(Math.min(1, Math.max(0, progress)));
      if (video.currentTime >= end - 0.04 || video.ended) {
        window.clearInterval(timer);
        video.pause();
        music?.pause();
        if (recorder.state !== "inactive") recorder.stop();
      }
    }, 100);

    recorder.start(200);
    if (music) void music.play().catch(() => undefined);
    void video.play().catch((err: unknown) => {
      window.clearInterval(timer);
      if (recorder.state !== "inactive") recorder.stop();
      reject(err instanceof Error ? err : new Error("Playback could not start."));
    });
  });

  videoNode.disconnect();
  videoNode.connect(ctx.destination);
  if (musicNode) {
    musicNode.disconnect();
    musicNode.connect(ctx.destination);
  }
  musicGain?.disconnect();

  if (!blob.size) throw new Error("Export produced an empty file.");
  return { blob, mime, audio: hasAudio };
}

function wait(target: EventTarget, event: string) {
  return new Promise<void>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      target.removeEventListener(event, onEvent);
      reject(new Error("The video did not seek in time."));
    }, 8000);
    const onEvent = () => {
      window.clearTimeout(timer);
      resolve();
    };
    target.addEventListener(event, onEvent, { once: true });
  });
}
