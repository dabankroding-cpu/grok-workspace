create table if not exists profiles (
  user_id text primary key,
  display_name text not null default '',
  plan text not null default 'free',
  trial_ends_at timestamptz,
  trial_used boolean not null default false,
  ai_calls_month integer not null default 0,
  ai_period text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists projects (
  id text primary key,
  user_id text not null,
  title text not null,
  source_name text not null default '',
  duration_sec double precision not null default 0,
  width integer not null default 0,
  height integer not null default 0,
  template_id text not null default 'cinematic',
  status text not null default 'draft',
  editor jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists projects_user_updated_idx on projects (user_id, updated_at desc);
