import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import type { Clip, MusicSuggestion } from "@/lib/editor-types";
import { captionsEstimated, captionsFromWords } from "@/lib/media";
import { limitsFor, type PlanId } from "@/lib/plans";
import { round2 } from "@/lib/utils";

/**
 * Server-side xAI calls. The key is XAI_API_KEY, injected for preview and
 * deploy. Never send it to the browser.
 * - Clip ranking and music search: POST https://api.x.ai/v1/chat/completions (grok-4.5)
 * - Captions: POST https://api.x.ai/v1/stt (grok-voice-transcribe-2.0)
 */

type AiFail = { ok: false; error: string };

function timeoutSignal(ms: number) {
  if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
    return AbortSignal.timeout(ms);
  }
  const controller = new AbortController();
  setTimeout(() => controller.abort(), ms);
  return controller.signal;
}

function num(value: unknown, fallback = 0) {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

async function planOf(sql: Sql, userId: string): Promise<PlanId> {
  const rows = await sql<{ plan: string }>`select plan from profiles where user_id = ${userId}`;
  return rows[0]?.plan === "trial" ? "trial" : "free";
}

async function charge(sql: Sql, userId: string): Promise<{ ok: true; refund: () => Promise<void> } | AiFail> {
  const plan = await planOf(sql, userId);
  const limit = limitsFor(plan).maxAiPerMonth;
  const updated = await sql<{ ai_calls_month: number }>`
    update profiles
    set ai_calls_month = ai_calls_month + 1
    where user_id = ${userId} and ai_calls_month < ${limit}
    returning ai_calls_month
  `;
  if (!updated.length) {
    return {
      ok: false,
      error: `Monthly AI limit reached (${limit} on ${plan === "trial" ? "the Pro trial" : "Free"}).`,
    };
  }
  return {
    ok: true,
    refund: async () => {
      await sql`
        update profiles
        set ai_calls_month = greatest(ai_calls_month - 1, 0)
        where user_id = ${userId}
      `;
    },
  };
}

async function owns(sql: Sql, userId: string, projectId: string) {
  const rows = await sql<{ id: string }>`
    select id from projects where id = ${projectId} and user_id = ${userId}
  `;
  return rows.length > 0;
}

function apiKey() {
  return process.env.XAI_API_KEY?.trim() || "";
}

function statusError(status: number) {
  if (status === 401 || status === 403) return "AI credentials were rejected.";
  if (status === 402 || status === 429) return "AI quota is used up or rate-limited. Try again later.";
  return `AI request failed (${status}).`;
}

function parseModelJson(text: string): unknown {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced?.[1] ?? trimmed;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("The model did not return JSON.");
  return JSON.parse(body.slice(start, end + 1));
}

type RankInput = {
  projectId: string;
  duration: number;
  peaks: { t: number; energy: number }[];
  frames: { t: number; dataUrl: string }[];
};

function readRank(input: unknown): RankInput {
  if (!input || typeof input !== "object") throw new Error("Missing analysis.");
  const o = input as Record<string, unknown>;
  const projectId = typeof o.projectId === "string" ? o.projectId.slice(0, 80) : "";
  if (projectId.length < 8) throw new Error("Missing project.");
  const duration = num(o.duration);
  if (duration <= 0 || duration > 8 * 60 + 1) throw new Error("Video length is out of range.");
  const peaks = Array.isArray(o.peaks)
    ? o.peaks.slice(0, 80).flatMap((peak) => {
        if (!peak || typeof peak !== "object") return [];
        const p = peak as Record<string, unknown>;
        const t = num(p.t, NaN);
        const energy = num(p.energy, NaN);
        if (!Number.isFinite(t) || !Number.isFinite(energy)) return [];
        return [{ t: Math.max(0, Math.min(duration, t)), energy: Math.max(0, energy) }];
      })
    : [];
  const frames = Array.isArray(o.frames)
    ? o.frames.slice(0, 3).flatMap((frame) => {
        if (!frame || typeof frame !== "object") return [];
        const f = frame as Record<string, unknown>;
        const dataUrl = typeof f.dataUrl === "string" ? f.dataUrl : "";
        if (!dataUrl.startsWith("data:image/jpeg;base64,") || dataUrl.length > 180_000) return [];
        return [{ t: Math.max(0, num(f.t)), dataUrl }];
      })
    : [];
  return { projectId, duration, peaks, frames };
}

export const rankClips = createServerFn({ method: "POST" })
  .validator(readRank)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; summary: string; clips: Clip[] } | AiFail> => {
    const key = apiKey();
    if (!key) return { ok: false, error: "AI is not available in this environment." };
    const sql = await getSql();
    if (!(await owns(sql, context.userId, data.projectId))) {
      return { ok: false, error: "Project not found." };
    }
    const charged = await charge(sql, context.userId);
    if (!charged.ok) return charged;

    const peakText = data.peaks.length
      ? data.peaks.map((p) => `${p.t}s:${p.energy}`).join(", ")
      : "none";
    const content: unknown[] = [
      {
        type: "text",
        text: `You help cut a vertical short from a ${round2(data.duration)} second video.
Audio energy peaks (time : RMS): ${peakText}.
Up to 3 JPEG frames are attached with their timestamps.
Return JSON only:
{"summary":"one sentence","clips":[{"start":0,"end":1,"title":"","reason":"","score":0.5,"platform":"tiktok"}]}
Rules: 3 to 6 clips. Each clip is 4 to 18 seconds and stays inside 0..${round2(data.duration)}.
When peaks exist, start a clip within 2 seconds of a peak. platform is tiktok, shorts, or reels.
Do not invent spoken lines. If the frames are unclear, say so and rank by energy.`,
      },
      ...data.frames.map((frame) => ({
        type: "image_url",
        image_url: { url: frame.dataUrl },
      })),
    ];

    let res: Response;
    try {
      res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.2,
          max_tokens: 900,
          messages: [
            { role: "system", content: "Reply with JSON only." },
            { role: "user", content },
          ],
        }),
        signal: timeoutSignal(60_000),
      });
    } catch {
      await charged.refund();
      return { ok: false, error: "Could not reach the AI service. This call was not counted." };
    }
    if (!res.ok) return { ok: false, error: statusError(res.status) };
    try {
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content ?? "";
      const parsed = parseModelJson(text) as { summary?: unknown; clips?: unknown };
      const summary = typeof parsed.summary === "string" ? parsed.summary.replace(/\s+/g, " ").trim().slice(0, 500) : "";
      const clips = sanitizeAiClips(parsed.clips, data.duration);
      if (!clips.length) {
        return { ok: false, error: summary || "The model did not return in-range clips." };
      }
      return { ok: true, summary, clips };
    } catch {
      return { ok: false, error: "The model reply could not be read." };
    }
  });

function sanitizeAiClips(value: unknown, duration: number): Clip[] {
  if (!Array.isArray(value)) return [];
  const platforms = new Set(["tiktok", "shorts", "reels"]);
  const clips: Clip[] = [];
  for (const item of value.slice(0, 8)) {
    if (!item || typeof item !== "object") continue;
    const o = item as Record<string, unknown>;
    let start = Math.max(0, Math.min(duration, num(o.start, NaN)));
    let end = Math.max(0, Math.min(duration, num(o.end, NaN)));
    if (!Number.isFinite(num(o.start, NaN)) || !Number.isFinite(num(o.end, NaN))) continue;
    if (end - start < 4) end = Math.min(duration, start + 4);
    if (end - start > 18) end = start + 18;
    if (end > duration) {
      end = duration;
      start = Math.max(0, end - 8);
    }
    if (end - start < 3) continue;
    const title = typeof o.title === "string" ? o.title.replace(/\s+/g, " ").trim().slice(0, 80) : "";
    const reason = typeof o.reason === "string" ? o.reason.replace(/\s+/g, " ").trim().slice(0, 280) : "";
    clips.push({
      id: crypto.randomUUID(),
      start: round2(start),
      end: round2(end),
      title: title || "Ranked moment",
      reason: reason || "Ranked from the peaks and frames sent with this request.",
      score: Math.min(1, Math.max(0, num(o.score, 0.5))),
      platform: platforms.has(String(o.platform)) ? (o.platform as Clip["platform"]) : "tiktok",
      source: "ai",
    });
  }
  return clips.slice(0, 6);
}

type MusicInput = {
  projectId: string;
  templateId: string;
  duration: number;
  summary: string;
  excerpt: string;
};

function readMusic(input: unknown): MusicInput {
  if (!input || typeof input !== "object") throw new Error("Missing music request.");
  const o = input as Record<string, unknown>;
  const projectId = typeof o.projectId === "string" ? o.projectId.slice(0, 80) : "";
  if (projectId.length < 8) throw new Error("Missing project.");
  return {
    projectId,
    templateId: typeof o.templateId === "string" ? o.templateId.slice(0, 40) : "cinematic",
    duration: Math.max(0, num(o.duration)),
    summary: typeof o.summary === "string" ? o.summary.slice(0, 500) : "",
    excerpt: typeof o.excerpt === "string" ? o.excerpt.slice(0, 400) : "",
  };
}

export const suggestMusic = createServerFn({ method: "POST" })
  .validator(readMusic)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: true; suggestions: MusicSuggestion[] } | AiFail> => {
    const key = apiKey();
    if (!key) return { ok: false, error: "AI is not available in this environment." };
    const sql = await getSql();
    if (!(await owns(sql, context.userId, data.projectId))) return { ok: false, error: "Project not found." };
    const charged = await charge(sql, context.userId);
    if (!charged.ok) return charged;
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.4,
          max_tokens: 700,
          messages: [
            { role: "system", content: "Reply with JSON only." },
            {
              role: "user",
              content: `Suggest music searches for a ${round2(data.duration)}s vertical edit.
Template: ${data.templateId}.
Visual/energy notes: ${data.summary || "none"}.
Caption excerpt: ${data.excerpt || "none"}.
Return {"suggestions":[{"mood":"","bpm":120,"search":"","why":""}]} with 4 items.
search is a library query (genre, instruments, energy). Do not claim a track is included or licensed.
why must refer to this edit, not a generic playlist.`,
            },
          ],
        }),
        signal: timeoutSignal(45_000),
      });
      if (!res.ok) return { ok: false, error: statusError(res.status) };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const parsed = parseModelJson(body.choices?.[0]?.message?.content ?? "") as { suggestions?: unknown };
      const suggestions = sanitizeMusic(parsed.suggestions);
      if (!suggestions.length) return { ok: false, error: "The model did not return music searches." };
      return { ok: true, suggestions };
    } catch {
      await charged.refund();
      return { ok: false, error: "Could not reach the AI service. This call was not counted." };
    }
  });

function sanitizeMusic(value: unknown): MusicSuggestion[] {
  if (!Array.isArray(value)) return [];
  const out: MusicSuggestion[] = [];
  for (const item of value.slice(0, 6)) {
    if (!item || typeof item !== "object") continue;
    const o = item as Record<string, unknown>;
    const search = typeof o.search === "string" ? o.search.replace(/\s+/g, " ").trim().slice(0, 140) : "";
    if (!search) continue;
    out.push({
      id: crypto.randomUUID(),
      mood: typeof o.mood === "string" ? o.mood.slice(0, 40) : "match",
      bpm: Math.min(220, Math.max(60, Math.round(num(o.bpm, 120)))),
      search,
      why: typeof o.why === "string" ? o.why.replace(/\s+/g, " ").trim().slice(0, 240) : "",
    });
  }
  return out.slice(0, 4);
}

type TranscribeInput = { projectId: string; wavBase64: string; offsetSec: number };

function readTranscribe(input: unknown): TranscribeInput {
  if (!input || typeof input !== "object") throw new Error("Missing audio.");
  const o = input as Record<string, unknown>;
  const projectId = typeof o.projectId === "string" ? o.projectId.slice(0, 80) : "";
  const wavBase64 = typeof o.wavBase64 === "string" ? o.wavBase64 : "";
  if (projectId.length < 8) throw new Error("Missing project.");
  if (wavBase64.length < 1000 || wavBase64.length > 4_000_000) throw new Error("Audio slice is the wrong size.");
  return { projectId, wavBase64, offsetSec: Math.max(0, num(o.offsetSec)) };
}

export const transcribeClip = createServerFn({ method: "POST" })
  .validator(readTranscribe)
  .middleware([authMiddleware])
  .handler(async ({
    context,
    data,
  }): Promise<
    | {
        ok: true;
        text: string;
        timing: "words" | "estimated";
        captions: ReturnType<typeof captionsFromWords>;
      }
    | AiFail
  > => {
    const key = apiKey();
    if (!key) return { ok: false, error: "AI is not available in this environment." };
    const sql = await getSql();
    if (!(await owns(sql, context.userId, data.projectId))) return { ok: false, error: "Project not found." };
    const plan = await planOf(sql, context.userId);
    const maxSec = limitsFor(plan).maxTranscribeSec;

    let bytes: Buffer;
    try {
      bytes = Buffer.from(data.wavBase64, "base64");
    } catch {
      return { ok: false, error: "Audio slice could not be read." };
    }
    if (bytes.length < 1000 || bytes.length > 3_200_000) return { ok: false, error: "Audio slice is the wrong size." };
    if (bytes.subarray(0, 4).toString("ascii") !== "RIFF") return { ok: false, error: "Audio slice is not a WAV file." };
    const sampleRate = bytes.readUInt32LE(24);
    const dataSize = bytes.readUInt32LE(40);
    const duration = sampleRate > 0 ? dataSize / 2 / sampleRate : 0;
    if (duration > maxSec + 1.5) {
      return { ok: false, error: `Transcription on this plan is limited to ${maxSec} seconds.` };
    }

    const charged = await charge(sql, context.userId);
    if (!charged.ok) return charged;

    try {
      const form = new FormData();
      form.append("model", "grok-voice-transcribe-2.0");
      form.append("file", new Blob([new Uint8Array(bytes)], { type: "audio/wav" }), "clip.wav");
      const res = await fetch("https://api.x.ai/v1/stt", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}` },
        body: form,
        signal: timeoutSignal(90_000),
      });
      if (!res.ok) return { ok: false, error: statusError(res.status) };
      const body = (await res.json()) as {
        text?: string;
        words?: { text?: string; start?: number; end?: number }[];
      };
      const text = (body.text ?? "").replace(/\s+/g, " ").trim();
      if (!text) return { ok: false, error: "No speech detected in that range." };
      const words = (body.words ?? []).flatMap((word) => {
        const token = (word.text ?? "").trim();
        if (!token) return [];
        const start = num(word.start, NaN);
        const end = num(word.end, NaN);
        if (!Number.isFinite(start) || !Number.isFinite(end)) return [];
        return [{ text: token, start, end: Math.max(start, end) }];
      });
      if (words.length) {
        return { ok: true, text, timing: "words", captions: captionsFromWords(words, data.offsetSec) };
      }
      return {
        ok: true,
        text,
        timing: "estimated",
        captions: captionsEstimated(text, data.offsetSec, data.offsetSec + duration),
      };
    } catch {
      await charged.refund();
      return { ok: false, error: "Could not reach speech-to-text. This call was not counted." };
    }
  });
