import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md font-medium transition-[transform,opacity,background-color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-smooth)] disabled:pointer-events-none disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-bright/70 active:scale-[0.98] motion-reduce:transform-none",
  {
    variants: {
      variant: {
        primary:
          "bg-primary text-primary-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_55%,transparent),0_12px_32px_-16px_var(--color-primary)] hover:brightness-110",
        secondary: "border border-line bg-surface-2 text-fg hover:border-accent/40",
        ghost: "bg-transparent text-fg hover:bg-surface-2",
        danger: "border border-danger/40 bg-transparent text-danger hover:bg-danger/10",
      },
      size: {
        md: "min-h-11 px-4 text-sm",
        sm: "min-h-10 px-3 text-sm",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export function buttonClass({
  variant,
  size,
  className,
}: VariantProps<typeof buttonVariants> & { className?: string } = {}) {
  return cn(buttonVariants({ variant, size }), className);
}

export function Button({
  variant,
  size,
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return <button type={type} className={buttonClass({ variant, size, className })} {...props} />;
}
