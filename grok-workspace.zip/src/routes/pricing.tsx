import { createFileRoute } from "@tanstack/react-router";
import { PlanCards } from "@/components/plan-cards";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useAccount } from "@/lib/use-account";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
});

function PricingPage() {
  const { user, isPending } = useCurrentUserState();
  const { account, loading, reload } = useAccount(user?.id);
  return (
    <div className="min-h-dvh bg-bg">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-4 py-12">
        <h1 className="font-display text-4xl font-semibold tracking-tight">Pricing</h1>
        <p className="mt-3 max-w-2xl text-muted">
          Free is usable: three projects, 20-second exports, and ten AI calls a month. Pro is the higher limit. Because card checkout is not connected, every account can start one 7-day Pro trial. Nothing is charged. When it ends, the account returns to Free.
        </p>
        <div className="mt-8">
          <PlanCards account={account} loading={isPending || (!!user && loading)} signedIn={!!user} onChanged={reload} />
        </div>
        <section className="mt-10 max-w-2xl space-y-3 text-sm text-muted">
          <h2 className="font-display text-xl font-semibold text-fg">What AI uses</h2>
          <p>
            Clip ranking and music searches call Grok (`grok-4.5`) at `https://api.x.ai/v1/chat/completions`. Captions call `https://api.x.ai/v1/stt` with `grok-voice-transcribe-2.0`. Both run on the server with `XAI_API_KEY`.
          </p>
          <p>
            On the hosted app that key is injected when you publish. You do not paste it into the page. If it is missing, those buttons return an error and peak detection, manual captions, effects, and export still work.
          </p>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
