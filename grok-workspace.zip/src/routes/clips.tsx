import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/shell";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClass } from "@/components/ui/button";
import { rankClips } from "@/lib/ai.server";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { createProjectFromFile } from "@/lib/create-project";
import { sanitizeEditor, type Clip } from "@/lib/editor-types";
import { audioEnergy, clipsFromEnergy, downsamplePeaks, sampleFrames } from "@/lib/media";
import { getProject, listProjects, updateProject } from "@/lib/projects.server";
import type { Project, ProjectSummary } from "@/lib/project-types";
import { useAccount } from "@/lib/use-account";
import { loadBlob, saveBlob, videoKey } from "@/lib/video-db";
import { errorText, formatTime } from "@/lib/utils";

export const Route = createFileRoute("/clips")({
  component: ClipsPage,
});

function ClipsPage() {
  return (
    <AppShell>
      <Clips />
    </AppShell>
  );
}

function Clips() {
  const { user } = useCurrentUserState();
  const { account, reload } = useAccount(user?.id);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [project, setProject] = useState<Project | null>(null);
  const [file, setFile] = useState<Blob | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [clips, setClips] = useState<Clip[]>([]);

  useEffect(() => {
    if (!user?.id) return;
    listProjects()
      .then(setProjects)
      .catch((err: unknown) => toast.error(errorText(err, "Could not load projects.")));
  }, [user?.id]);

  async function openProject(id: string) {
    setBusy("Opening project…");
    try {
      const row = await getProject({ data: id });
      if (!row) {
        toast.error("Project not found.");
        return;
      }
      setProject(row);
      setClips(sanitizeEditor(row.editor).clips);
      const blob = await loadBlob(videoKey(id));
      setFile(blob);
      if (!blob) toast.message("The video is not on this device. Attach it to analyze.");
    } catch (err) {
      toast.error(errorText(err, "Could not open the project."));
    } finally {
      setBusy(null);
    }
  }

  async function upload(next: File) {
    setBusy("Creating project…");
    try {
      const result = await createProjectFromFile(next, "cinematic");
      if (result.warning) toast.error(result.warning);
      setProject(result.project);
      setFile(result.stored ? next : null);
      setClips([]);
      setProjects(await listProjects());
      reload();
    } catch (err) {
      toast.error(errorText(err, "Could not upload."));
    } finally {
      setBusy(null);
    }
  }

  async function saveClips(next: Clip[], summary: string, peaks: { t: number; energy: number }[], aiRanked: boolean) {
    if (!project) return;
    const editor = sanitizeEditor({
      ...project.editor,
      clips: next,
      activeClipId: next[0]?.id ?? null,
      analysis: {
        summary: summary || project.editor.analysis?.summary || "",
        peaks: peaks.length ? peaks : (project.editor.analysis?.peaks ?? []),
        aiRanked,
      },
    });
    const saved = await updateProject({
      data: {
        id: project.id,
        title: project.title,
        sourceName: project.sourceName,
        durationSec: project.durationSec,
        width: project.width,
        height: project.height,
        templateId: project.templateId,
        status: "ready",
        editor,
      },
    });
    setProject(saved);
    setClips(saved.editor.clips);
  }

  async function onEnergy() {
    if (!project || !file) {
      toast.error("Attach the video on this device first.");
      return;
    }
    setBusy("Measuring loudness…");
    try {
      const peaks = await audioEnergy(file, project.durationSec);
      const next = clipsFromEnergy(peaks, project.durationSec);
      await saveClips(next, project.editor.analysis?.summary ?? "", downsamplePeaks(peaks, 160), project.editor.analysis?.aiRanked ?? false);
      toast.success(`Found ${next.length} energy ranges.`);
    } catch (err) {
      toast.error(errorText(err, "Could not measure audio."));
    } finally {
      setBusy(null);
    }
  }

  async function onRank() {
    if (!project || !file) {
      toast.error("Attach the video on this device first.");
      return;
    }
    setBusy("Ranking with Grok…");
    try {
      const measured = project.editor.analysis?.peaks?.length
        ? project.editor.analysis.peaks
        : downsamplePeaks(await audioEnergy(file, project.durationSec), 80);
      const times = [...measured].sort((a, b) => b.energy - a.energy).slice(0, 3).map((peak) => peak.t);
      const frames = await sampleFrames(file, times.length ? times : [project.durationSec * 0.2, project.durationSec * 0.5]);
      const result = await rankClips({
        data: { projectId: project.id, duration: project.durationSec, peaks: measured.slice(0, 80), frames },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      await saveClips(result.clips, result.summary, downsamplePeaks(measured, 160), true);
      reload();
      toast.success("Clips ranked.");
    } catch (err) {
      toast.error(errorText(err, "Could not rank clips."));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Clip generator</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Turn a longer video into short ranges for TikTok, Shorts, and Reels. Energy detection stays on this device. AI ranking is a separate step and only runs when you press the button.
        </p>
      </div>
      {busy ? <p className="rounded-xl border border-line bg-surface px-3 py-2 text-sm text-muted">{busy}</p> : null}
      <div className="flex flex-wrap gap-2">
        <label className={buttonClass()}>
          Upload and generate
          <input
            className="sr-only"
            type="file"
            accept="video/mp4,video/webm,video/quicktime"
            disabled={Boolean(busy)}
            onChange={(event) => {
              const next = event.target.files?.[0];
              event.target.value = "";
              if (next) void upload(next);
            }}
          />
        </label>
        {project && !file ? (
          <label className={buttonClass({ variant: "secondary" })}>
            Attach video
            <input
              className="sr-only"
              type="file"
              accept="video/mp4,video/webm,video/quicktime"
              onChange={(event) => {
                const next = event.target.files?.[0];
                event.target.value = "";
                if (next && project) {
                  void saveBlob(videoKey(project.id), next)
                    .then(() => setFile(next))
                    .catch((err: unknown) => toast.error(errorText(err, "Could not store the video.")));
                }
              }}
            />
          </label>
        ) : null}
      </div>
      {projects.length ? (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {projects.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => void openProject(item.id)}
              className={`min-h-11 shrink-0 rounded-md border px-3 text-sm ${project?.id === item.id ? "border-accent/50 bg-surface" : "border-line"}`}
            >
              {item.title}
            </button>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted">No projects yet. Upload a video to start.</p>
      )}
      {project ? (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-2xl font-semibold">{project.title}</h2>
            <Link to="/editor/$projectId" params={{ projectId: project.id }} className={buttonClass({ variant: "secondary", size: "sm" })}>
              Open in editor
            </Link>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" disabled={Boolean(busy) || !file} onClick={() => void onEnergy()}>
              Find energy peaks
            </Button>
            <Button disabled={Boolean(busy) || !file} onClick={() => void onRank()}>
              Rank with AI
            </Button>
          </div>
          <p className="text-sm text-muted">
            {account ? `${account.aiCallsMonth}/${account.aiLimit} AI calls used this month.` : null}
            {!file ? " Video file missing on this device." : null}
          </p>
          {project.editor.analysis?.summary ? <p className="text-sm">{project.editor.analysis.summary}</p> : null}
          <ul className="grid gap-3">
            {clips.map((item) => (
              <li key={item.id} className="rounded-2xl border border-line bg-surface p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-medium">{item.title}</h3>
                  <Badge tone={item.source === "ai" ? "primary" : "accent"}>{item.source === "ai" ? "Grok" : "Audio energy"}</Badge>
                  <Badge>{item.platform}</Badge>
                </div>
                <p className="mt-2 font-mono text-xs tabular-nums text-muted">
                  {formatTime(item.start)} – {formatTime(item.end)} · score {Math.round(item.score * 100)}
                </p>
                <p className="mt-2 text-sm text-muted">{item.reason}</p>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
