import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Clapperboard, CreditCard, LayoutTemplate, Scissors, Settings } from "lucide-react";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/utils";

const links = [
  { to: "/dashboard", label: "Projects", icon: Clapperboard },
  { to: "/clips", label: "Clips", icon: Scissors },
  { to: "/templates", label: "Templates", icon: LayoutTemplate },
  { to: "/pricing", label: "Pricing", icon: CreditCard },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="min-h-dvh bg-bg px-4 py-6">
        <div className="mx-auto max-w-6xl space-y-4">
          <div className="h-12 w-48 rounded-md bg-surface-2 motion-safe:animate-pulse" />
          <div className="h-40 rounded-2xl bg-surface motion-safe:animate-pulse" />
        </div>
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4">
          <Logo />
          <nav className="hidden items-center gap-1 md:flex">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="rounded-md px-3 py-2 text-sm text-muted hover:bg-surface-2 hover:text-fg"
                activeProps={{ className: "rounded-md px-3 py-2 text-sm text-fg bg-surface-2" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/settings" aria-label="Settings" className="grid size-11 place-items-center rounded-md hover:bg-surface-2">
              <Settings className="size-5" />
            </Link>
            <UserButton />
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-6 pb-28 md:pb-10">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 pb-[env(safe-area-inset-bottom)] md:hidden">
        <ul className="grid grid-cols-4">
          {links.map((link) => {
            const Icon = link.icon;
            return (
              <li key={link.to}>
                <Link
                  to={link.to}
                  className="flex min-h-14 flex-col items-center justify-center gap-1 text-xs text-muted"
                  activeProps={{ className: "flex min-h-14 flex-col items-center justify-center gap-1 text-xs text-accent-bright" }}
                >
                  <Icon className={cn("size-5")} />
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
