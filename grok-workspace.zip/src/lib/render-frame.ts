import type { EditorState, Grade } from "@/lib/editor-types";

const GRADE_FILTER: Record<Grade, string> = {
  none: "none",
  cinematic: "contrast(1.08) saturate(0.88) brightness(0.98)",
  phonk: "contrast(1.28) saturate(0.7) brightness(0.82)",
  anime: "contrast(1.06) saturate(1.35) brightness(1.04)",
  nba: "contrast(1.16) saturate(1.12) brightness(1.02)",
  gaming: "contrast(1.2) saturate(1.18) brightness(0.96)",
};

const FILL: Record<EditorState["captionStyle"]["color"], string> = {
  paper: "#f4f5f7",
  blue: "#d6e6ff",
  violet: "#e0dbff",
};

const FONT: Record<EditorState["captionStyle"]["font"], string> = {
  syne: "Syne",
  manrope: "Manrope",
  mono: "IBM Plex Mono",
};

export function renderFrame(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  state: EditorState,
  time: number,
) {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#07080c";
  ctx.fillRect(0, 0, w, h);
  if (video.readyState < 2 || video.videoWidth < 2) {
    return;
  }

  const fx = effectsAt(state, time);
  const crop = coverSource(video.videoWidth, video.videoHeight, state.crop);
  const zoom = 1 + fx.zoom * 0.22;
  const sw = Math.max(2, crop.sw / zoom);
  const sh = Math.max(2, crop.sh / zoom);
  const sx = crop.sx + (crop.sw - sw) / 2;
  const sy = crop.sy + (crop.sh - sh) / 2;
  const shakeX = fx.shake ? Math.sin(time * 46) * fx.shake * 22 : 0;
  const shakeY = fx.shake ? Math.cos(time * 33) * fx.shake * 14 : 0;
  const blur = fx.blur > 0.04 ? `blur(${(fx.blur * 7).toFixed(1)}px)` : "";
  const grade = GRADE_FILTER[state.grade] ?? "none";
  const filter = [grade, blur].filter((part) => part && part !== "none").join(" ") || "none";

  ctx.save();
  ctx.filter = filter;
  ctx.drawImage(video, sx, sy, sw, sh, shakeX, shakeY, w, h);
  ctx.restore();

  if (state.grade === "cinematic") {
    const vignette = ctx.createRadialGradient(w / 2, h / 2, w * 0.2, w / 2, h / 2, w * 0.78);
    vignette.addColorStop(0, "rgba(0,0,0,0)");
    vignette.addColorStop(1, "rgba(0,0,0,0.38)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, w, h);
  }

  if (fx.flash > 0.02) {
    ctx.fillStyle = `rgba(244,245,247,${Math.min(0.72, fx.flash)})`;
    ctx.fillRect(0, 0, w, h);
  }

  drawCaptions(ctx, state, time, w, h);
}

function effectsAt(state: EditorState, time: number) {
  let zoom = 0;
  let shake = 0;
  let flash = 0;
  let blur = 0;
  for (const effect of state.effects) {
    if (time < effect.start || time > effect.end) continue;
    const span = Math.max(0.001, effect.end - effect.start);
    const u = (time - effect.start) / span;
    if (effect.type === "zoom") zoom = Math.max(zoom, effect.intensity);
    if (effect.type === "shake") shake = Math.max(shake, effect.intensity);
    if (effect.type === "flash") flash = Math.max(flash, effect.intensity * (1 - u));
    if (effect.type === "blur") blur = Math.max(blur, effect.intensity * Math.sin(Math.min(1, u) * Math.PI));
  }
  return { zoom, shake, flash, blur };
}

function coverSource(vw: number, vh: number, crop: EditorState["crop"]) {
  const target = 9 / 16;
  const src = vw / vh;
  if (src > target) {
    const sw = vh * target;
    const maxX = vw - sw;
    const sx = crop === "left" ? 0 : crop === "right" ? maxX : maxX / 2;
    return { sx, sy: 0, sw, sh: vh };
  }
  const sh = vw / target;
  const maxY = Math.max(0, vh - sh);
  return { sx: 0, sy: maxY / 2, sw: vw, sh };
}

function drawCaptions(
  ctx: CanvasRenderingContext2D,
  state: EditorState,
  time: number,
  w: number,
  h: number,
) {
  const caption = [...state.captions].reverse().find((item) => time >= item.start && time <= item.end);
  if (!caption) return;
  const style = state.captionStyle;
  const fontSize = (style.size === "sm" ? 0.042 : style.size === "lg" ? 0.068 : 0.054) * h;
  const font = FONT[style.font];
  const weight = 700;
  ctx.font = `${weight} ${fontSize}px ${font}, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const lines = wrapText(ctx, caption.text, w * 0.86).slice(0, 3);
  const lineHeight = fontSize * 1.18;
  const anchor = style.position === "center" ? h * 0.5 : h * 0.78;
  const top = anchor - ((lines.length - 1) * lineHeight) / 2;
  const age = time - caption.start;

  ctx.save();
  if (style.effect === "pop" && age >= 0 && age < 0.16) {
    const scale = 0.94 + (age / 0.16) * 0.06;
    ctx.translate(w / 2, anchor);
    ctx.scale(scale, scale);
    ctx.translate(-w / 2, -anchor);
  }
  ctx.lineJoin = "round";
  ctx.miterLimit = 2;
  ctx.lineWidth = style.effect === "outline" ? Math.max(8, fontSize * 0.18) : Math.max(6, fontSize * 0.14);
  ctx.strokeStyle = "rgba(5,6,10,0.88)";
  ctx.fillStyle = FILL[style.color];
  ctx.shadowColor = "rgba(0,0,0,0.45)";
  ctx.shadowBlur = 10;

  if (style.effect === "karaoke" && caption.words.length) {
    drawKaraoke(ctx, caption.words, time, w / 2, top, lineHeight, fontSize, w * 0.86);
  } else {
    lines.forEach((line, index) => {
      const y = top + index * lineHeight;
      ctx.strokeText(line, w / 2, y);
      ctx.fillText(line, w / 2, y);
    });
  }
  ctx.restore();
}

function drawKaraoke(
  ctx: CanvasRenderingContext2D,
  words: { text: string; start: number; end: number }[],
  time: number,
  center: number,
  top: number,
  lineHeight: number,
  fontSize: number,
  maxWidth: number,
) {
  const gap = fontSize * 0.28;
  const widths = words.map((word) => ctx.measureText(word.text).width);
  const lines: number[][] = [];
  let current: number[] = [];
  let width = 0;
  widths.forEach((wordWidth, index) => {
    const next = width + (current.length ? gap : 0) + wordWidth;
    if (current.length && next > maxWidth) {
      lines.push(current);
      current = [index];
      width = wordWidth;
    } else {
      current.push(index);
      width = next;
    }
  });
  if (current.length) lines.push(current);
  lines.slice(0, 3).forEach((line, lineIndex) => {
    const lineWidth = line.reduce((sum, index, i) => sum + widths[index] + (i ? gap : 0), 0);
    let x = center - lineWidth / 2;
    const y = top + lineIndex * lineHeight;
    for (const index of line) {
      const word = words[index];
      const active = time >= word.start && time <= word.end + 0.05;
      ctx.fillStyle = active ? "#9ec4ff" : "#f4f5f7";
      const drawX = x + widths[index] / 2;
      ctx.strokeText(word.text, drawX, y);
      ctx.fillText(word.text, drawX, y);
      x += widths[index] + gap;
    }
  });
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (line && ctx.measureText(test).width > maxWidth) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}
