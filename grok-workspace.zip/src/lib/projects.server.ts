import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import { sanitizeEditor, type EditorState } from "@/lib/editor-types";
import { limitsFor, type Account, type PlanId } from "@/lib/plans";
import type { Project, ProjectSummary } from "@/lib/project-types";
import { initialEditor, TEMPLATES } from "@/lib/templates-data";

async function ensureProfile(sql: Sql, userId: string) {
  const period = new Date().toISOString().slice(0, 7);
  await sql`
    insert into profiles (user_id, ai_period)
    values (${userId}, ${period})
    on conflict (user_id) do nothing
  `;
  await sql`
    update profiles
    set ai_calls_month = 0, ai_period = ${period}
    where user_id = ${userId} and ai_period <> ${period}
  `;
  await sql`
    update profiles
    set plan = 'free'
    where user_id = ${userId}
      and plan = 'trial'
      and trial_ends_at is not null
      and trial_ends_at <= now()
  `;
}

function num(value: unknown, fallback = 0) {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

type ProfileRow = {
  display_name: string;
  plan: string;
  trial_ends_at: string | null;
  trial_used: boolean;
  ai_calls_month: number;
};

async function readAccount(sql: Sql, userId: string): Promise<Account> {
  await ensureProfile(sql, userId);
  const profiles = await sql<ProfileRow>`
    select display_name, plan, trial_ends_at::text as trial_ends_at, trial_used, ai_calls_month
    from profiles
    where user_id = ${userId}
  `;
  const counts = await sql<{ n: number }>`
    select count(*)::int as n from projects where user_id = ${userId}
  `;
  const row = profiles[0];
  const plan: PlanId = row?.plan === "trial" ? "trial" : "free";
  const limits = limitsFor(plan);
  return {
    displayName: row?.display_name ?? "",
    plan,
    trialEndsAt: row?.trial_ends_at ?? null,
    trialUsed: row?.trial_used === true,
    aiCallsMonth: num(row?.ai_calls_month),
    aiLimit: limits.maxAiPerMonth,
    projectCount: num(counts[0]?.n),
    projectLimit: limits.maxProjects,
    maxExportSec: limits.maxExportSec,
    maxTranscribeSec: limits.maxTranscribeSec,
    templateIds: limits.templateIds,
  };
}

function mapProject(row: Record<string, unknown>): Project {
  return {
    id: String(row.id),
    title: String(row.title ?? ""),
    sourceName: String(row.source_name ?? ""),
    durationSec: num(row.duration_sec),
    width: num(row.width),
    height: num(row.height),
    templateId: String(row.template_id ?? "cinematic"),
    status: String(row.status ?? "draft"),
    editor: sanitizeEditor(row.editor),
    createdAt: String(row.created_at ?? ""),
    updatedAt: String(row.updated_at ?? ""),
  };
}

function mapSummary(row: Record<string, unknown>): ProjectSummary {
  return {
    id: String(row.id),
    title: String(row.title ?? ""),
    sourceName: String(row.source_name ?? ""),
    durationSec: num(row.duration_sec),
    width: num(row.width),
    height: num(row.height),
    templateId: String(row.template_id ?? "cinematic"),
    status: String(row.status ?? "draft"),
    createdAt: String(row.created_at ?? ""),
    updatedAt: String(row.updated_at ?? ""),
    clipCount: num(row.clip_count),
    captionCount: num(row.caption_count),
  };
}

const projectSelect = `
  id, title, source_name, duration_sec, width, height, template_id, status, editor,
  created_at::text as created_at, updated_at::text as updated_at
`;

export const getAccount = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Account> => {
    const sql = await getSql();
    return readAccount(sql, context.userId);
  });

export const listProjects = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProjectSummary[]> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<Record<string, unknown>>`
      select id, title, source_name, duration_sec, width, height, template_id, status,
             created_at::text as created_at, updated_at::text as updated_at,
             coalesce(jsonb_array_length(coalesce(editor->'clips', '[]'::jsonb)), 0)::int as clip_count,
             coalesce(jsonb_array_length(coalesce(editor->'captions', '[]'::jsonb)), 0)::int as caption_count
      from projects
      where user_id = ${context.userId}
      order by updated_at desc
    `;
    return rows.map(mapSummary);
  });

export const getProject = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const id = typeof input === "string" ? input : "";
    if (!/^[0-9a-f-]{8,80}$/i.test(id) && id.length < 8) throw new Error("Missing project.");
    return id.slice(0, 80);
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Project | null> => {
    const sql = await getSql();
    const found = await sql.query<Record<string, unknown>>(
      `select ${projectSelect} from projects where id = $1 and user_id = $2`,
      [data, context.userId],
    );
    return found[0] ? mapProject(found[0]) : null;
  });

type CreateInput = {
  title: string;
  sourceName: string;
  durationSec: number;
  width: number;
  height: number;
  templateId: string;
};

function readCreate(input: unknown): CreateInput {
  if (!input || typeof input !== "object") throw new Error("Missing project details.");
  const o = input as Record<string, unknown>;
  const title = typeof o.title === "string" ? o.title.trim().slice(0, 80) : "";
  const sourceName = typeof o.sourceName === "string" ? o.sourceName.trim().slice(0, 160) : "";
  const durationSec = num(o.durationSec);
  const width = Math.round(num(o.width));
  const height = Math.round(num(o.height));
  const templateId = typeof o.templateId === "string" ? o.templateId : "cinematic";
  if (!title) throw new Error("Title is required.");
  if (durationSec <= 0 || durationSec > 8 * 60 + 1) throw new Error("Video length is out of range.");
  if (width < 2 || height < 2) throw new Error("Video dimensions are missing.");
  if (!TEMPLATES.some((t) => t.id === templateId)) throw new Error("Unknown template.");
  return { title, sourceName, durationSec, width, height, templateId };
}

export const createProject = createServerFn({ method: "POST" })
  .validator(readCreate)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Project> => {
    const sql = await getSql();
    const account = await readAccount(sql, context.userId);
    if (account.projectCount >= account.projectLimit) {
      throw new Error(
        `Project limit reached (${account.projectLimit} on ${account.plan === "trial" ? "the Pro trial" : "Free"}).`,
      );
    }
    if (!account.templateIds.includes(data.templateId)) {
      throw new Error("That template is included with the Pro trial.");
    }
    const id = crypto.randomUUID();
    const editor = initialEditor(data.templateId, data.durationSec);
    const rows = await sql.query<Record<string, unknown>>(
      `insert into projects (
         id, user_id, title, source_name, duration_sec, width, height, template_id, status, editor
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,'draft',$9::jsonb)
       returning ${projectSelect}`,
      [
        id,
        context.userId,
        data.title,
        data.sourceName,
        data.durationSec,
        data.width,
        data.height,
        data.templateId,
        JSON.stringify(editor),
      ],
    );
    return mapProject(rows[0]);
  });

type UpdateInput = {
  id: string;
  title: string;
  sourceName: string;
  durationSec: number;
  width: number;
  height: number;
  templateId: string;
  status: string;
  editor: EditorState;
};

function readUpdate(input: unknown): UpdateInput {
  if (!input || typeof input !== "object") throw new Error("Missing project.");
  const o = input as Record<string, unknown>;
  const id = typeof o.id === "string" ? o.id.slice(0, 80) : "";
  if (id.length < 8) throw new Error("Missing project.");
  const title = typeof o.title === "string" ? o.title.trim().slice(0, 80) : "";
  if (!title) throw new Error("Title is required.");
  const templateId = typeof o.templateId === "string" ? o.templateId : "cinematic";
  if (!TEMPLATES.some((t) => t.id === templateId)) throw new Error("Unknown template.");
  const status = o.status === "ready" || o.status === "exported" ? o.status : "draft";
  const editor = sanitizeEditor(o.editor);
  const payload = JSON.stringify(editor);
  if (payload.length > 250_000) throw new Error("This project is too large to save.");
  return {
    id,
    title,
    sourceName: typeof o.sourceName === "string" ? o.sourceName.slice(0, 160) : "",
    durationSec: Math.min(8 * 60 + 1, Math.max(0.1, num(o.durationSec))),
    width: Math.round(num(o.width)),
    height: Math.round(num(o.height)),
    templateId,
    status,
    editor,
  };
}

export const updateProject = createServerFn({ method: "POST" })
  .validator(readUpdate)
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Project> => {
    const sql = await getSql();
    const account = await readAccount(sql, context.userId);
    if (!account.templateIds.includes(data.templateId)) {
      throw new Error("That template is included with the Pro trial.");
    }
    const rows = await sql.query<Record<string, unknown>>(
      `update projects
       set title = $1, source_name = $2, duration_sec = $3, width = $4, height = $5,
           template_id = $6, status = $7, editor = $8::jsonb, updated_at = now()
       where id = $9 and user_id = $10
       returning ${projectSelect}`,
      [
        data.title,
        data.sourceName,
        data.durationSec,
        data.width,
        data.height,
        data.templateId,
        data.status,
        JSON.stringify(data.editor),
        data.id,
        context.userId,
      ],
    );
    if (!rows[0]) throw new Error("Project not found.");
    return mapProject(rows[0]);
  });

export const deleteProject = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const id = typeof input === "string" ? input.slice(0, 80) : "";
    if (id.length < 8) throw new Error("Missing project.");
    return id;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from projects where id = ${data} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const updateDisplayName = createServerFn({ method: "POST" })
  .validator((input: unknown) => (typeof input === "string" ? input.trim().slice(0, 40) : ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Account> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    await sql`update profiles set display_name = ${data} where user_id = ${context.userId}`;
    return readAccount(sql, context.userId);
  });

export const startTrial = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Account> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{ user_id: string }>`
      update profiles
      set plan = 'trial',
          trial_used = true,
          trial_ends_at = now() + interval '7 days'
      where user_id = ${context.userId}
        and trial_used = false
        and plan = 'free'
      returning user_id
    `;
    if (!rows.length) throw new Error("The Pro trial was already used on this account.");
    return readAccount(sql, context.userId);
  });
