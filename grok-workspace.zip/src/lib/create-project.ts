import { createProject } from "@/lib/projects.server";
import { assertUpload, probeVideo } from "@/lib/media";
import { saveBlob, videoKey } from "@/lib/video-db";
import type { Project } from "@/lib/project-types";
import { templateById } from "@/lib/templates-data";
import { errorText } from "@/lib/utils";

export async function createProjectFromFile(
  file: File,
  templateId: string,
): Promise<{ project: Project; stored: boolean; warning?: string }> {
  const meta = await probeVideo(file);
  assertUpload(file, meta);
  const template = templateById(templateId);
  const title = (file.name.replace(/\.[^.]+$/, "") || "Untitled").slice(0, 80);
  const project = await createProject({
    data: {
      title,
      sourceName: file.name.slice(0, 160),
      durationSec: meta.duration,
      width: meta.width,
      height: meta.height,
      templateId: template.id,
    },
  });
  try {
    await saveBlob(videoKey(project.id), file);
    return { project, stored: true };
  } catch (err) {
    return {
      project,
      stored: false,
      warning: errorText(err, "The project was saved, but the video could not be stored on this device."),
    };
  }
}
