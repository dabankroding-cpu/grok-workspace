import { useCallback, useEffect, useState } from "react";
import { getAccount } from "@/lib/projects.server";
import type { Account } from "@/lib/plans";
import { errorText } from "@/lib/utils";

export function useAccount(userId: string | undefined) {
  const [account, setAccount] = useState<Account | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(userId));

  const reload = useCallback(() => {
    if (!userId) {
      setAccount(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    getAccount()
      .then((next) => {
        setAccount(next);
        setError(null);
      })
      .catch((err: unknown) => setError(errorText(err, "Could not load the account.")))
      .finally(() => setLoading(false));
  }, [userId]);

  useEffect(() => {
    reload();
  }, [reload]);

  return { account, error, loading, reload, setAccount };
}
