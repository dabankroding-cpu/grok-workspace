import { createFileRoute } from "@tanstack/react-router";
import { EditorScreen } from "@/components/editor/screen";
import { AppShell } from "@/components/shell";

export const Route = createFileRoute("/editor/$projectId")({
  component: EditorPage,
});

function EditorPage() {
  const { projectId } = Route.useParams();
  return (
    <AppShell>
      <EditorScreen projectId={projectId} />
    </AppShell>
  );
}
