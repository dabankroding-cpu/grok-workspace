import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useEditor } from "@/components/editor/context";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { rankClips, suggestMusic, transcribeClip } from "@/lib/ai.server";
import { recordCanvas } from "@/lib/export-video";
import type { EffectType, Grade } from "@/lib/editor-types";
import {
  audioEnergy,
  blobToBase64,
  clipsFromEnergy,
  downsamplePeaks,
  extractWav,
  sampleFrames,
} from "@/lib/media";
import { TEMPLATES } from "@/lib/templates-data";
import { errorText, formatTime, round2, slugify } from "@/lib/utils";

const tabs = ["Moments", "Captions", "Effects", "Music", "Export"] as const;

export function Tools() {
  const api = useEditor();
  const [tab, setTab] = useState<(typeof tabs)[number]>("Moments");
  const locked = Boolean(api.busy);

  return (
    <section className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((item) => (
          <button
            key={item}
            type="button"
            aria-pressed={tab === item}
            onClick={() => setTab(item)}
            className={`min-h-10 shrink-0 rounded-md px-3 text-sm ${tab === item ? "bg-surface-2 text-fg" : "text-muted"}`}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="mt-4">
        {tab === "Moments" ? <Moments locked={locked} /> : null}
        {tab === "Captions" ? <Captions locked={locked} /> : null}
        {tab === "Effects" ? <Effects locked={locked} /> : null}
        {tab === "Music" ? <Music locked={locked} /> : null}
        {tab === "Export" ? <ExportPanel locked={locked} /> : null}
      </div>
    </section>
  );
}

function Moments({ locked }: { locked: boolean }) {
  const api = useEditor();
  const clip = api.editor.clips.find((item) => item.id === api.editor.activeClipId);

  async function onEnergy() {
    if (!api.videoFile) {
      toast.error("The video file is not on this device.");
      return;
    }
    api.setBusy("Measuring loudness in this browser…");
    try {
      const peaks = await audioEnergy(api.videoFile, api.media.durationSec);
      const clips = clipsFromEnergy(peaks, api.media.durationSec);
      api.updateEditor((editor) => ({
        ...editor,
        clips,
        activeClipId: clips[0]?.id ?? null,
        analysis: {
          summary: editor.analysis?.summary ?? "",
          peaks: downsamplePeaks(peaks, 160),
          aiRanked: editor.analysis?.aiRanked ?? false,
        },
      }));
      api.setStatus(api.status === "exported" ? "exported" : "ready");
      toast.success(`Marked ${clips.length} range${clips.length === 1 ? "" : "s"} from the soundtrack.`);
    } catch (err) {
      toast.error(errorText(err, "Could not measure audio."));
    } finally {
      api.setBusy(null);
    }
  }

  async function onRank() {
    if (!api.videoFile) {
      toast.error("The video file is not on this device.");
      return;
    }
    if (api.account.aiCallsMonth >= api.account.aiLimit) {
      toast.error("Monthly AI limit reached.");
      return;
    }
    api.setBusy("Sending peaks and frames to Grok…");
    try {
      const peaks = api.editor.analysis?.peaks ?? downsamplePeaks(await audioEnergy(api.videoFile, api.media.durationSec), 80);
      const times = [...peaks].sort((a, b) => b.energy - a.energy).slice(0, 3).map((peak) => peak.t);
      const fallback = [0.15, 0.5, 0.8].map((ratio) => api.media.durationSec * ratio);
      const frames = await sampleFrames(api.videoFile, times.length ? times : fallback);
      const result = await rankClips({
        data: {
          projectId: api.project.id,
          duration: api.media.durationSec,
          peaks: peaks.slice(0, 80),
          frames,
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      api.updateEditor((editor) => ({
        ...editor,
        clips: result.clips,
        activeClipId: result.clips[0]?.id ?? null,
        analysis: {
          summary: result.summary,
          peaks: editor.analysis?.peaks?.length ? editor.analysis.peaks : downsamplePeaks(peaks, 160),
          aiRanked: true,
        },
      }));
      api.setStatus("ready");
      api.reloadAccount();
      toast.success("Grok ranked clips from the peaks and frames.");
    } catch (err) {
      toast.error(errorText(err, "Could not rank clips."));
    } finally {
      api.setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Energy peaks are measured here from the audio track. Rank with AI sends those times plus up to three JPEG frames to Grok. It does not upload the whole video.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" disabled={locked || !api.videoFile} onClick={() => void onEnergy()}>
          Find energy peaks
        </Button>
        <Button disabled={locked || !api.videoFile} onClick={() => void onRank()}>
          Rank with AI
        </Button>
      </div>
      {api.editor.analysis?.summary ? <p className="text-sm">{api.editor.analysis.summary}</p> : null}
      <ul className="space-y-2">
        {api.editor.clips.map((item) => (
          <li key={item.id}>
            <button
              type="button"
              onClick={() => {
                api.updateEditor((editor) => ({ ...editor, activeClipId: item.id }));
                if (api.videoRef.current) api.videoRef.current.currentTime = item.start;
              }}
              className={`w-full rounded-xl border p-3 text-left ${item.id === clip?.id ? "border-accent/50 bg-bg" : "border-line"}`}
            >
              <span className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{item.title}</span>
                <Badge tone={item.source === "ai" ? "primary" : "accent"}>{item.source === "ai" ? "Grok" : "Audio energy"}</Badge>
                <Badge>{item.platform}</Badge>
              </span>
              <span className="mt-1 block font-mono text-xs tabular-nums text-muted">
                {formatTime(item.start)} – {formatTime(item.end)} · {Math.round(item.score * 100)}
              </span>
              <span className="mt-1 block text-sm text-muted">{item.reason}</span>
            </button>
          </li>
        ))}
      </ul>
      {!api.editor.clips.length ? <p className="text-sm text-muted">No clips yet.</p> : null}
    </div>
  );
}

function Captions({ locked }: { locked: boolean }) {
  const api = useEditor();
  const clip = api.editor.clips.find((item) => item.id === api.editor.activeClipId);
  const start = clip?.start ?? 0;
  const end = Math.min(api.media.durationSec, clip?.end ?? api.media.durationSec, start + api.account.maxTranscribeSec);

  async function onTranscribe() {
    if (!api.videoFile) {
      toast.error("The video file is not on this device.");
      return;
    }
    api.setBusy("Transcribing speech…");
    try {
      const wav = await extractWav(api.videoFile, start, Math.max(start + 0.4, end));
      const wavBase64 = await blobToBase64(wav);
      const result = await transcribeClip({
        data: { projectId: api.project.id, wavBase64, offsetSec: start },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      api.updateEditor((editor) => {
        const kept = editor.captions.filter((caption) => caption.end < start - 0.05 || caption.start > end + 0.05);
        const next = result.captions.map((caption) => ({ ...caption, id: crypto.randomUUID() }));
        return { ...editor, captions: [...kept, ...next].sort((a, b) => a.start - b.start) };
      });
      api.setStatus("ready");
      api.reloadAccount();
      toast.success(
        result.timing === "words"
          ? "Captions placed with word times from speech-to-text."
          : "Speech was transcribed, but word times were missing, so lines are spaced evenly.",
      );
    } catch (err) {
      toast.error(errorText(err, "Could not transcribe."));
    } finally {
      api.setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Sends a WAV of {formatTime(start)}–{formatTime(end)} to xAI speech-to-text. This plan allows {api.account.maxTranscribeSec}s per call.
        {clip && clip.end - clip.start > api.account.maxTranscribeSec ? " The selected clip is longer, so only the first part of it is sent." : ""}
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Font">
          <Select
            value={api.editor.captionStyle.font}
            onChange={(event) =>
              api.updateEditor((editor) => ({
                ...editor,
                captionStyle: { ...editor.captionStyle, font: event.target.value as typeof editor.captionStyle.font },
              }))
            }
          >
            <option value="syne">Syne</option>
            <option value="manrope">Manrope</option>
            <option value="mono">Mono</option>
          </Select>
        </Field>
        <Field label="Color">
          <Select
            value={api.editor.captionStyle.color}
            onChange={(event) =>
              api.updateEditor((editor) => ({
                ...editor,
                captionStyle: { ...editor.captionStyle, color: event.target.value as typeof editor.captionStyle.color },
              }))
            }
          >
            <option value="paper">Paper</option>
            <option value="blue">Blue</option>
            <option value="violet">Violet</option>
          </Select>
        </Field>
        <Field label="Effect">
          <Select
            value={api.editor.captionStyle.effect}
            onChange={(event) =>
              api.updateEditor((editor) => ({
                ...editor,
                captionStyle: { ...editor.captionStyle, effect: event.target.value as typeof editor.captionStyle.effect },
              }))
            }
          >
            <option value="none">Clean</option>
            <option value="pop">Pop</option>
            <option value="karaoke">Word highlight</option>
            <option value="outline">Heavy outline</option>
          </Select>
        </Field>
        <Field label="Size and place">
          <div className="grid grid-cols-2 gap-2">
            <Select
              value={api.editor.captionStyle.size}
              onChange={(event) =>
                api.updateEditor((editor) => ({
                  ...editor,
                  captionStyle: { ...editor.captionStyle, size: event.target.value as typeof editor.captionStyle.size },
                }))
              }
            >
              <option value="sm">Small</option>
              <option value="md">Medium</option>
              <option value="lg">Large</option>
            </Select>
            <Select
              value={api.editor.captionStyle.position}
              onChange={(event) =>
                api.updateEditor((editor) => ({
                  ...editor,
                  captionStyle: {
                    ...editor.captionStyle,
                    position: event.target.value as typeof editor.captionStyle.position,
                  },
                }))
              }
            >
              <option value="bottom">Bottom</option>
              <option value="center">Center</option>
            </Select>
          </div>
        </Field>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button disabled={locked || !api.videoFile} onClick={() => void onTranscribe()}>
          Generate captions
        </Button>
        <Button
          variant="secondary"
          disabled={locked}
          onClick={() => {
            const at = api.videoRef.current?.currentTime ?? 0;
            api.updateEditor((editor) => ({
              ...editor,
              captions: [
                ...editor.captions,
                {
                  id: crypto.randomUUID(),
                  start: round2(at),
                  end: round2(Math.min(api.media.durationSec, at + 2)),
                  text: "New line",
                  words: [],
                  timing: "manual" as const,
                },
              ].sort((a, b) => a.start - b.start),
            }));
          }}
        >
          Add line at playhead
        </Button>
      </div>
      <ul className="space-y-3">
        {api.editor.captions.map((caption) => (
          <li key={caption.id} className="rounded-xl border border-line p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <Badge>{caption.timing === "words" ? "Word times" : caption.timing === "estimated" ? "Estimated" : "Manual"}</Badge>
              <button
                type="button"
                className="text-sm text-danger"
                onClick={() =>
                  api.updateEditor((editor) => ({
                    ...editor,
                    captions: editor.captions.filter((item) => item.id !== caption.id),
                  }))
                }
              >
                Remove
              </button>
            </div>
            <Textarea
              value={caption.text}
              onChange={(event) =>
                api.updateEditor((editor) => ({
                  ...editor,
                  captions: editor.captions.map((item) =>
                    item.id === caption.id ? { ...item, text: event.target.value.slice(0, 240) } : item,
                  ),
                }))
              }
            />
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Field label="Start">
                <Input
                  type="number"
                  min={0}
                  step={0.1}
                  value={caption.start}
                  onChange={(event) =>
                    api.updateEditor((editor) => ({
                      ...editor,
                      captions: editor.captions.map((item) =>
                        item.id === caption.id ? { ...item, start: Math.max(0, Number(event.target.value) || 0) } : item,
                      ),
                    }))
                  }
                />
              </Field>
              <Field label="End">
                <Input
                  type="number"
                  min={0}
                  step={0.1}
                  value={caption.end}
                  onChange={(event) =>
                    api.updateEditor((editor) => ({
                      ...editor,
                      captions: editor.captions.map((item) =>
                        item.id === caption.id
                          ? { ...item, end: Math.max(item.start + 0.2, Number(event.target.value) || 0) }
                          : item,
                      ),
                    }))
                  }
                />
              </Field>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Effects({ locked }: { locked: boolean }) {
  const api = useEditor();

  function add(type: EffectType) {
    const at = api.videoRef.current?.currentTime ?? 0;
    const length = type === "flash" ? 0.12 : type === "blur" ? 0.8 : 1;
    api.updateEditor((editor) => ({
      ...editor,
      effects: [
        ...editor.effects,
        {
          id: crypto.randomUUID(),
          type,
          start: round2(at),
          end: round2(Math.min(api.media.durationSec, at + length)),
          intensity: type === "flash" ? 0.55 : 0.75,
        },
      ],
    }));
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Zooms, shakes, flashes, and blur are drawn on the preview canvas and burned into the export. Grades are canvas filters, not a fake overlay.
      </p>
      <Field label="Template pack">
        <Select value={api.templateId} onChange={(event) => api.setTemplate(event.target.value)} disabled={locked}>
          {TEMPLATES.map((template) => (
            <option key={template.id} value={template.id} disabled={!api.account.templateIds.includes(template.id)}>
              {template.name}
              {api.account.templateIds.includes(template.id) ? "" : " (Pro trial)"}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Grade">
          <Select
            value={api.editor.grade}
            onChange={(event) => api.updateEditor((editor) => ({ ...editor, grade: event.target.value as Grade }))}
          >
            <option value="none">None</option>
            <option value="cinematic">Cinematic</option>
            <option value="gaming">Gaming</option>
            <option value="nba">NBA</option>
            <option value="anime">Anime</option>
            <option value="phonk">Phonk</option>
          </Select>
        </Field>
        <Field label="Crop">
          <Select
            value={api.editor.crop}
            onChange={(event) =>
              api.updateEditor((editor) => ({
                ...editor,
                crop: event.target.value as typeof editor.crop,
              }))
            }
          >
            <option value="center">Center</option>
            <option value="left">Left</option>
            <option value="right">Right</option>
          </Select>
        </Field>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" disabled={locked} onClick={() => add("zoom")}>
          Zoom
        </Button>
        <Button size="sm" variant="secondary" disabled={locked} onClick={() => add("shake")}>
          Shake
        </Button>
        <Button size="sm" variant="secondary" disabled={locked} onClick={() => add("flash")}>
          Flash
        </Button>
        <Button size="sm" variant="secondary" disabled={locked} onClick={() => add("blur")}>
          Motion blur
        </Button>
      </div>
      <ul className="space-y-2">
        {api.editor.effects.map((effect) => (
          <li key={effect.id} className="flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2 text-sm">
            <span className="capitalize">
              {effect.type} · {formatTime(effect.start)}–{formatTime(effect.end)}
            </span>
            <button
              type="button"
              className="text-danger"
              onClick={() =>
                api.updateEditor((editor) => ({
                  ...editor,
                  effects: editor.effects.filter((item) => item.id !== effect.id),
                }))
              }
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Music({ locked }: { locked: boolean }) {
  const api = useEditor();

  async function onSuggest() {
    api.setBusy("Asking for music searches…");
    try {
      const result = await suggestMusic({
        data: {
          projectId: api.project.id,
          templateId: api.templateId,
          duration: api.media.durationSec,
          summary: api.editor.analysis?.summary ?? "",
          excerpt: api.editor.captions
            .slice(0, 4)
            .map((caption) => caption.text)
            .join(" "),
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      api.updateEditor((editor) => ({ ...editor, music: result.suggestions }));
      api.reloadAccount();
      toast.success("Search ideas are ready. ClipForge does not play those tracks.");
    } catch (err) {
      toast.error(errorText(err, "Could not suggest music."));
    } finally {
      api.setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Suggestions are search queries for a library you license yourself. To hear music in the preview and export, upload a file you have rights to.
      </p>
      <Button disabled={locked} onClick={() => void onSuggest()}>
        Suggest searches
      </Button>
      <ul className="space-y-2">
        {api.editor.music.map((item) => (
          <li key={item.id} className="rounded-xl border border-line p-3">
            <p className="font-medium">{item.search}</p>
            <p className="mt-1 text-sm text-muted">
              {item.mood} · {item.bpm} BPM
            </p>
            {item.why ? <p className="mt-1 text-sm text-muted">{item.why}</p> : null}
            <button
              type="button"
              className="mt-2 text-sm text-accent-bright"
              onClick={() => {
                void navigator.clipboard.writeText(item.search).then(
                  () => toast.success("Search copied."),
                  () => toast.error("Could not copy."),
                );
              }}
            >
              Copy search
            </button>
          </li>
        ))}
      </ul>
      <Field label={api.editor.musicName ? `Your track: ${api.editor.musicName}` : "Upload a track"}>
        <input
          type="file"
          accept="audio/*"
          disabled={locked}
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void api.attachMusic(file).catch((err: unknown) => toast.error(errorText(err, "Could not attach audio.")));
          }}
        />
      </Field>
      {api.musicUrl ? (
        <Button variant="danger" size="sm" onClick={() => void api.clearMusic()}>
          Remove uploaded track
        </Button>
      ) : null}
    </div>
  );
}

function ExportPanel({ locked }: { locked: boolean }) {
  const api = useEditor();
  const clip = api.editor.clips.find((item) => item.id === api.editor.activeClipId);
  const [range, setRange] = useState({ start: 0, end: Math.min(api.media.durationSec, api.account.maxExportSec) });
  const [progress, setProgress] = useState(0);
  const [download, setDownload] = useState<string | null>(null);

  useEffect(() => {
    const start = clip?.start ?? 0;
    const proposed = clip?.end ?? Math.min(api.media.durationSec, start + api.account.maxExportSec);
    const end = Math.min(api.media.durationSec, start + api.account.maxExportSec, proposed);
    setRange({ start: round2(start), end: round2(Math.max(start + 0.4, end)) });
  }, [api.account.maxExportSec, api.media.durationSec, clip?.end, clip?.id, clip?.start]);

  useEffect(() => {
    return () => {
      if (download) URL.revokeObjectURL(download);
    };
  }, [download]);

  async function onExport() {
    const video = api.videoRef.current;
    const canvas = api.canvasRef.current;
    if (!video || !canvas || !api.videoUrl) {
      toast.error("Attach the video on this device before exporting.");
      return;
    }
    const span = range.end - range.start;
    if (span < 0.4) {
      toast.error("Pick a longer range.");
      return;
    }
    if (span > api.account.maxExportSec + 0.05) {
      toast.error(`This plan exports up to ${api.account.maxExportSec} seconds.`);
      return;
    }
    api.exportingRef.current = true;
    api.setBusy("Recording the preview in real time…");
    setProgress(0);
    try {
      const result = await recordCanvas({
        video,
        canvas,
        start: range.start,
        end: range.end,
        music: api.musicUrl ? api.musicRef.current : null,
        onProgress: setProgress,
      });
      const url = URL.createObjectURL(result.blob);
      setDownload((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
      const link = document.createElement("a");
      link.href = url;
      link.download = `clipforge-${slugify(api.title)}.webm`;
      link.click();
      api.setStatus("exported");
      toast.success(result.audio ? "WebM export is ready." : "Exported the picture, but this browser exposed no audio track.");
    } catch (err) {
      toast.error(errorText(err, "Export failed."));
    } finally {
      api.exportingRef.current = false;
      api.setBusy(null);
    }
  }

  const pct = Math.round(progress * 100);

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Export plays the 9:16 canvas in real time and records a WebM. A {api.account.maxExportSec}s limit means the recording takes about that long. It is not a cloud render, and it is not an MP4.
      </p>
      <div className="grid grid-cols-2 gap-2">
        <Field label="In">
          <Input
            type="number"
            min={0}
            step={0.1}
            value={range.start}
            onChange={(event) => setRange((prev) => ({ ...prev, start: Math.max(0, Number(event.target.value) || 0) }))}
          />
        </Field>
        <Field label="Out">
          <Input
            type="number"
            min={0}
            step={0.1}
            value={range.end}
            onChange={(event) => setRange((prev) => ({ ...prev, end: Math.max(0, Number(event.target.value) || 0) }))}
          />
        </Field>
      </div>
      <p className="text-sm tabular-nums text-muted">
        Length {formatTime(Math.max(0, range.end - range.start))} · plan max {api.account.maxExportSec}s
      </p>
      {api.busy?.startsWith("Recording") ? (
        <div className="h-1.5 overflow-hidden rounded-full bg-surface-2" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} role="progressbar">
          <div className="h-full bg-accent" style={{ width: `${pct}%` }} />
        </div>
      ) : null}
      <Button disabled={locked || !api.videoUrl} onClick={() => void onExport()}>
        {locked && api.busy?.startsWith("Recording") ? `Exporting ${pct}%` : "Export WebM"}
      </Button>
      {download ? (
        <a className="block text-sm text-accent-bright" href={download} download={`clipforge-${slugify(api.title)}.webm`}>
          Download again
        </a>
      ) : null}
    </div>
  );
}
