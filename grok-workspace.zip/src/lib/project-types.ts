import type { EditorState } from "@/lib/editor-types";

export type Project = {
  id: string;
  title: string;
  sourceName: string;
  durationSec: number;
  width: number;
  height: number;
  templateId: string;
  status: string;
  editor: EditorState;
  createdAt: string;
  updatedAt: string;
};

export type ProjectSummary = {
  id: string;
  title: string;
  sourceName: string;
  durationSec: number;
  width: number;
  height: number;
  templateId: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  clipCount: number;
  captionCount: number;
};
