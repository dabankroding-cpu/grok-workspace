import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

function safeNext(value: unknown) {
  if (typeof value !== "string") return "/dashboard";
  if (!value.startsWith("/") || value.startsWith("//") || value.includes("://")) return "/dashboard";
  return value.slice(0, 200);
}

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>): { next?: string } => {
    if (typeof search.next !== "string") return {};
    return { next: safeNext(search.next) };
  },
  component: LoginPage,
});

function LoginPage() {
  const next = Route.useSearch().next ?? "/dashboard";
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (!isPending && user) window.location.replace(next);
  }, [isPending, next, user]);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (!email.includes("@") || password.length < 8) {
      setError("Use a valid email and a password of at least 8 characters.");
      return;
    }
    setPending(true);
    try {
      const result =
        mode === "up"
          ? await authClient.signUp.email({ email, password, name: name.trim() || email.split("@")[0] || "Editor" })
          : await authClient.signIn.email({ email, password });
      if (result.error) {
        setError(result.error.message ?? "Could not sign in.");
        setPending(false);
        return;
      }
      window.location.assign(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
      setPending(false);
    }
  }

  return (
    <div className="min-h-dvh bg-bg">
      <SiteHeader />
      <main className="mx-auto grid w-full max-w-md gap-6 px-4 py-12">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">
            {mode === "up" ? "Create your studio" : "Welcome back"}
          </h1>
          <p className="mt-2 text-sm text-muted">Google, X, or email. Projects are tied to this account.</p>
        </div>
        <div className="space-y-2">
          {GROK_PROVIDERS.map((provider) => (
            <Button
              key={provider.providerId}
              variant="secondary"
              className="w-full"
              disabled={pending || isPending}
              onClick={() => {
                setPending(true);
                setError(null);
                void signIn(provider.providerId, { callbackURL: next }).catch((err: unknown) => {
                  setPending(false);
                  setError(err instanceof Error ? err.message : "Sign-in failed.");
                });
              }}
            >
              Continue with {provider.label}
            </Button>
          ))}
        </div>
        <form className="space-y-3 rounded-2xl border border-line bg-surface p-4" onSubmit={(event) => void onSubmit(event)}>
          {mode === "up" ? (
            <Field label="Name">
              <Input value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" maxLength={40} />
            </Field>
          ) : null}
          <Field label="Email">
            <Input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              autoComplete="email"
              required
            />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete={mode === "up" ? "new-password" : "current-password"}
              minLength={8}
              required
            />
          </Field>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={pending}>
            {pending ? "Working…" : mode === "up" ? "Create account" : "Sign in"}
          </Button>
          <button
            type="button"
            className="text-sm text-accent-bright"
            onClick={() => {
              setMode(mode === "up" ? "in" : "up");
              setError(null);
            }}
          >
            {mode === "up" ? "Already have an account? Sign in" : "New here? Create an account"}
          </button>
        </form>
      </main>
    </div>
  );
}
