import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { startTrial } from "@/lib/projects.server";
import { PLANS, type Account } from "@/lib/plans";
import { errorText, formatDay } from "@/lib/utils";
import { Button, buttonClass } from "@/components/ui/button";

const rows = [
  { label: "Projects", free: String(PLANS.free.maxProjects), trial: String(PLANS.trial.maxProjects) },
  { label: "Export length", free: `${PLANS.free.maxExportSec}s`, trial: `${PLANS.trial.maxExportSec}s` },
  { label: "AI calls / month", free: String(PLANS.free.maxAiPerMonth), trial: String(PLANS.trial.maxAiPerMonth) },
  { label: "Caption window", free: `${PLANS.free.maxTranscribeSec}s`, trial: `${PLANS.trial.maxTranscribeSec}s` },
  { label: "Templates", free: "Cinematic, Gaming", trial: "All five" },
  { label: "Charge", free: "$0", trial: "$0 for 7 days" },
];

export function PlanCards({
  account,
  loading,
  signedIn,
  onChanged,
}: {
  account: Account | null;
  loading?: boolean;
  signedIn: boolean;
  onChanged?: () => void;
}) {
  const [pending, setPending] = useState(false);

  async function beginTrial() {
    setPending(true);
    try {
      await startTrial();
      toast.success("Pro trial started. It ends in 7 days. Nothing was charged.");
      onChanged?.();
    } catch (err) {
      toast.error(errorText(err, "Could not start the trial."));
    } finally {
      setPending(false);
    }
  }

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        <div className="h-80 rounded-2xl bg-surface motion-safe:animate-pulse" />
        <div className="h-80 rounded-2xl bg-surface motion-safe:animate-pulse" />
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <article className="rounded-2xl border border-line bg-surface p-4">
        <p className="text-sm text-muted">Free</p>
        <h3 className="mt-2 font-display text-3xl font-semibold">$0</h3>
        <p className="mt-2 text-sm text-muted">Enough to learn the editor and ship a few shorts.</p>
        <dl className="mt-5 space-y-3 text-sm">
          {rows.map((row) => (
            <div key={row.label} className="flex items-center justify-between gap-3 border-t border-line pt-3">
              <dt className="text-muted">{row.label}</dt>
              <dd className="tabular-nums">{row.free}</dd>
            </div>
          ))}
        </dl>
        <div className="mt-5">
          {signedIn ? (
            <Link to="/dashboard" className={buttonClass({ variant: "secondary", className: "w-full" })}>
              Go to projects
            </Link>
          ) : (
            <Link to="/login" className={buttonClass({ variant: "secondary", className: "w-full" })}>
              Create a free account
            </Link>
          )}
        </div>
      </article>

      <article className="rounded-2xl border border-line bg-surface p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_35%,transparent)]">
        <p className="text-sm text-primary-bright">Pro trial</p>
        <h3 className="mt-2 font-display text-3xl font-semibold">7 days</h3>
        <p className="mt-2 text-sm text-muted">
          The paid plan’s limits, without a card. Checkout is not connected, so this trial does not bill you.
        </p>
        <dl className="mt-5 space-y-3 text-sm">
          {rows.map((row) => (
            <div key={row.label} className="flex items-center justify-between gap-3 border-t border-line pt-3">
              <dt className="text-muted">{row.label}</dt>
              <dd className="tabular-nums">{row.trial}</dd>
            </div>
          ))}
        </dl>
        <div className="mt-5">
          {!signedIn ? (
            <Link to="/login" search={{ next: "/pricing" }} className={buttonClass({ className: "w-full" })}>
              Sign in to start the trial
            </Link>
          ) : account?.plan === "trial" ? (
            <p className="text-sm text-ok">Trial ends {formatDay(account.trialEndsAt)}.</p>
          ) : account?.trialUsed ? (
            <p className="text-sm text-muted">
              This account already used its trial and is back on Free. There is no paid checkout to extend it.
            </p>
          ) : (
            <Button className="w-full" disabled={pending} onClick={() => void beginTrial()}>
              {pending ? "Starting…" : "Start 7-day Pro trial"}
            </Button>
          )}
        </div>
      </article>
    </div>
  );
}
