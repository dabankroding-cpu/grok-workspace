import { TEMPLATES } from "@/lib/templates-data";

export type PlanId = "free" | "trial";

export type PlanLimits = {
  label: string;
  maxProjects: number;
  maxExportSec: number;
  maxAiPerMonth: number;
  maxTranscribeSec: number;
  templateIds: string[];
};

const FREE_IDS = TEMPLATES.filter((t) => t.tier === "free").map((t) => t.id);
const ALL_IDS = TEMPLATES.map((t) => t.id);

export const PLANS: Record<PlanId, PlanLimits> = {
  free: {
    label: "Free",
    maxProjects: 3,
    maxExportSec: 20,
    maxAiPerMonth: 10,
    maxTranscribeSec: 30,
    templateIds: FREE_IDS,
  },
  trial: {
    label: "Pro trial",
    maxProjects: 25,
    maxExportSec: 60,
    maxAiPerMonth: 40,
    maxTranscribeSec: 60,
    templateIds: ALL_IDS,
  },
};

export function limitsFor(plan: PlanId): PlanLimits {
  return PLANS[plan];
}

export type Account = {
  displayName: string;
  plan: PlanId;
  trialEndsAt: string | null;
  trialUsed: boolean;
  aiCallsMonth: number;
  aiLimit: number;
  projectCount: number;
  projectLimit: number;
  maxExportSec: number;
  maxTranscribeSec: number;
  templateIds: string[];
};
