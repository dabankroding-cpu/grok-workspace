const DB_NAME = "clipforge";
const STORE = "files";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open local storage for videos."));
  });
}

function request<T>(db: IDBDatabase, mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>) {
  return new Promise<T>((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const req = run(tx.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Local storage request failed."));
  });
}

export async function saveBlob(key: string, blob: Blob) {
  const db = await openDb();
  try {
    await request(db, "readwrite", (store) => store.put(blob, key));
  } catch (err) {
    const name = err instanceof DOMException ? err.name : "";
    if (name === "QuotaExceededError") {
      throw new Error("This browser refused to store the file. Free some space and try a shorter video.");
    }
    throw err instanceof Error ? err : new Error("Could not store the file on this device.");
  } finally {
    db.close();
  }
}

export async function loadBlob(key: string): Promise<Blob | null> {
  const db = await openDb();
  try {
    const result = await request<Blob | undefined>(db, "readonly", (store) => store.get(key));
    return result ?? null;
  } finally {
    db.close();
  }
}

export async function deleteBlob(key: string) {
  const db = await openDb();
  try {
    await request(db, "readwrite", (store) => store.delete(key));
  } finally {
    db.close();
  }
}

export const videoKey = (projectId: string) => `video:${projectId}`;
export const musicKey = (projectId: string) => `music:${projectId}`;
