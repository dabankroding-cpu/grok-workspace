import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { EditorProvider, type EditorApi } from "@/components/editor/context";
import { Stage } from "@/components/editor/stage";
import { Tools } from "@/components/editor/tools";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { sanitizeEditor, type EditorState } from "@/lib/editor-types";
import { assertUpload, probeVideo } from "@/lib/media";
import { getProject, updateProject } from "@/lib/projects.server";
import type { Project } from "@/lib/project-types";
import { applyTemplate } from "@/lib/templates-data";
import { useAccount } from "@/lib/use-account";
import { deleteBlob, loadBlob, musicKey, saveBlob, videoKey } from "@/lib/video-db";
import { errorText } from "@/lib/utils";
import { buttonClass } from "@/components/ui/button";

type MediaMeta = { durationSec: number; width: number; height: number; sourceName: string };

export function EditorScreen({ projectId }: { projectId: string }) {
  const { user } = useCurrentUserState();
  const { account, loading: accountLoading, reload, error: accountError } = useAccount(user?.id);
  const [project, setProject] = useState<Project | null>(null);
  const [missing, setMissing] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [templateId, setTemplateId] = useState("cinematic");
  const [status, setStatus] = useState("draft");
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [media, setMedia] = useState<MediaMeta | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<Blob | null>(null);
  const [musicUrl, setMusicUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [saveState, setSaveState] = useState<"saved" | "saving" | "error">("saved");
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const musicRef = useRef<HTMLAudioElement | null>(null);
  const exportingRef = useRef(false);
  const skipSave = useRef(true);

  useEffect(() => {
    if (!user?.id) return;
    let cancel = false;
    setMissing(false);
    setLoadError(null);
    getProject({ data: projectId })
      .then(async (row) => {
        if (cancel) return;
        if (!row) {
          setMissing(true);
          return;
        }
        setProject(row);
        setTitle(row.title);
        setTemplateId(row.templateId);
        setStatus(row.status);
        setEditor(sanitizeEditor(row.editor));
        setMedia({
          durationSec: row.durationSec,
          width: row.width,
          height: row.height,
          sourceName: row.sourceName,
        });
        const [video, music] = await Promise.all([loadBlob(videoKey(row.id)), loadBlob(musicKey(row.id))]);
        if (cancel) return;
        if (video) {
          setVideoFile(video);
          setVideoUrl(URL.createObjectURL(video));
        }
        if (music) setMusicUrl(URL.createObjectURL(music));
        skipSave.current = true;
      })
      .catch((err: unknown) => {
        if (!cancel) setLoadError(errorText(err, "Could not open this project."));
      });
    return () => {
      cancel = true;
    };
  }, [projectId, user?.id]);

  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  useEffect(() => {
    return () => {
      if (musicUrl) URL.revokeObjectURL(musicUrl);
    };
  }, [musicUrl]);

  useEffect(() => {
    if (!project || !editor || !media || !account) return;
    if (skipSave.current) {
      skipSave.current = false;
      return;
    }
    const handle = window.setTimeout(() => {
      setSaveState("saving");
      updateProject({
        data: {
          id: project.id,
          title: title.trim() || project.title,
          sourceName: media.sourceName,
          durationSec: media.durationSec,
          width: media.width,
          height: media.height,
          templateId,
          status,
          editor,
        },
      })
        .then(() => setSaveState("saved"))
        .catch((err: unknown) => {
          setSaveState("error");
          toast.error(errorText(err, "Could not save the project."));
        });
    }, 700);
    return () => window.clearTimeout(handle);
  }, [account, editor, media, project, status, templateId, title]);

  const api = useMemo<EditorApi | null>(() => {
    if (!project || !editor || !media || !account) return null;
    return {
      project,
      editor,
      updateEditor: (fn) => setEditor((prev) => (prev ? sanitizeEditor(fn(prev)) : prev)),
      title,
      setTitle,
      templateId,
      setTemplate: (id: string) => {
        if (!account.templateIds.includes(id)) {
          toast.error("That template is on the Pro trial.");
          return;
        }
        setTemplateId(id);
        setEditor((prev) => (prev ? applyTemplate(prev, id, media.durationSec) : prev));
        toast.success("Template applied. Captions and clips were kept. Effects were replaced.");
      },
      status,
      setStatus,
      media,
      videoUrl,
      videoFile,
      videoRef,
      canvasRef,
      musicRef,
      musicUrl,
      attachVideo: async (file: File) => {
        const meta = await probeVideo(file);
        assertUpload(file, meta);
        await saveBlob(videoKey(project.id), file);
        setVideoFile(file);
        setVideoUrl(URL.createObjectURL(file));
        setMedia({
          durationSec: meta.duration,
          width: meta.width,
          height: meta.height,
          sourceName: file.name.slice(0, 160),
        });
        toast.success("Video stored on this device.");
      },
      attachMusic: async (file: File) => {
        const ok = file.type.startsWith("audio/") || /\.(mp3|wav|m4a|ogg|aac)$/i.test(file.name);
        if (!ok) throw new Error("Choose an audio file you have the rights to use.");
        if (file.size > 20 * 1024 * 1024) throw new Error("Music files need to be under 20 MB.");
        await saveBlob(musicKey(project.id), file);
        setMusicUrl(URL.createObjectURL(file));
        setEditor((prev) => (prev ? { ...prev, musicName: file.name.slice(0, 120) } : prev));
        toast.success("Your track will play under the preview and the export.");
      },
      clearMusic: async () => {
        await deleteBlob(musicKey(project.id));
        setMusicUrl(null);
        setEditor((prev) => (prev ? { ...prev, musicName: null } : prev));
      },
      account,
      reloadAccount: reload,
      busy,
      setBusy,
      saveState,
      exportingRef,
    };
  }, [account, busy, editor, media, musicUrl, project, reload, saveState, status, templateId, title, videoFile, videoUrl]);

  if (loadError || accountError) {
    return <p className="text-sm text-danger">{loadError || accountError}</p>;
  }
  if (missing) {
    return (
      <div className="rounded-2xl border border-line bg-surface p-6">
        <h1 className="font-display text-2xl font-semibold">Project not found</h1>
        <p className="mt-2 text-sm text-muted">It may have been deleted, or it belongs to another account.</p>
        <Link to="/dashboard" className={buttonClass({ className: "mt-5" })}>
          Back to projects
        </Link>
      </div>
    );
  }
  if (!api || accountLoading) {
    return (
      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <div className="aspect-[9/16] rounded-2xl bg-surface motion-safe:animate-pulse" />
        <div className="h-80 rounded-2xl bg-surface motion-safe:animate-pulse" />
      </div>
    );
  }

  const saveLabel = api.saveState === "saving" ? "Saving" : api.saveState === "error" ? "Not saved" : "Saved";

  return (
    <EditorProvider value={api}>
      <audio ref={musicRef} src={musicUrl ?? undefined} preload="auto" className="hidden" />
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0 flex-1">
          <label className="text-xs font-medium text-muted" htmlFor="project-title">
            Project
          </label>
          <input
            id="project-title"
            value={title}
            onChange={(event) => setTitle(event.target.value.slice(0, 80))}
            className="mt-1 w-full max-w-xl bg-transparent font-display text-2xl font-semibold tracking-tight outline-none"
          />
        </div>
        <p className={`text-sm tabular-nums ${api.saveState === "error" ? "text-danger" : "text-muted"}`}>{saveLabel}</p>
      </div>
      {api.busy ? (
        <p className="mb-4 rounded-xl border border-line bg-surface px-3 py-2 text-sm text-muted">{api.busy}</p>
      ) : null}
      <div className="grid items-start gap-4 lg:grid-cols-[minmax(240px,340px)_1fr]">
        <Stage />
        <Tools />
      </div>
    </EditorProvider>
  );
}
