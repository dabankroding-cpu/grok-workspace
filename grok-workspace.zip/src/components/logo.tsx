import { Link } from "@tanstack/react-router";

export function Logo() {
  return (
    <Link to="/" className="inline-flex items-center gap-2 font-display text-lg font-semibold tracking-tight text-fg">
      <span className="grid size-7 place-items-center rounded-md bg-primary" aria-hidden="true">
        <span className="ml-0.5 block h-0 w-0 border-y-[5px] border-l-8 border-y-transparent border-l-primary-fg" />
      </span>
      ClipForge
    </Link>
  );
}
