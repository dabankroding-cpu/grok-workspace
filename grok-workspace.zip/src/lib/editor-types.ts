export type CaptionWord = { text: string; start: number; end: number };

export type Caption = {
  id: string;
  start: number;
  end: number;
  text: string;
  words: CaptionWord[];
  timing: "words" | "estimated" | "manual";
};

export type Clip = {
  id: string;
  start: number;
  end: number;
  title: string;
  reason: string;
  score: number;
  platform: "tiktok" | "shorts" | "reels";
  source: "energy" | "ai";
};

export type EffectType = "zoom" | "shake" | "flash" | "blur";

export type Effect = {
  id: string;
  type: EffectType;
  start: number;
  end: number;
  intensity: number;
};

export type MusicSuggestion = {
  id: string;
  mood: string;
  bpm: number;
  search: string;
  why: string;
};

export type CaptionStyle = {
  font: "syne" | "manrope" | "mono";
  color: "paper" | "blue" | "violet";
  effect: "none" | "pop" | "karaoke" | "outline";
  size: "sm" | "md" | "lg";
  position: "bottom" | "center";
};

export type Grade = "none" | "cinematic" | "phonk" | "anime" | "nba" | "gaming";

export type Analysis = {
  summary: string;
  peaks: { t: number; energy: number }[];
  aiRanked: boolean;
};

export type EditorState = {
  captions: Caption[];
  clips: Clip[];
  effects: Effect[];
  music: MusicSuggestion[];
  musicName: string | null;
  captionStyle: CaptionStyle;
  grade: Grade;
  crop: "center" | "left" | "right";
  activeClipId: string | null;
  analysis: Analysis | null;
};

const FONTS = new Set(["syne", "manrope", "mono"]);
const COLORS = new Set(["paper", "blue", "violet"]);
const CAP_EFFECTS = new Set(["none", "pop", "karaoke", "outline"]);
const SIZES = new Set(["sm", "md", "lg"]);
const POSITIONS = new Set(["bottom", "center"]);
const GRADES = new Set(["none", "cinematic", "phonk", "anime", "nba", "gaming"]);
const CROPS = new Set(["center", "left", "right"]);
const PLATFORMS = new Set(["tiktok", "shorts", "reels"]);
const EFFECT_TYPES = new Set(["zoom", "shake", "flash", "blur"]);

function num(value: unknown, fallback = 0) {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

function str(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

export function emptyCaptionStyle(): CaptionStyle {
  return { font: "syne", color: "paper", effect: "none", size: "md", position: "bottom" };
}

export function emptyEditor(): EditorState {
  return {
    captions: [],
    clips: [],
    effects: [],
    music: [],
    musicName: null,
    captionStyle: emptyCaptionStyle(),
    grade: "cinematic",
    crop: "center",
    activeClipId: null,
    analysis: null,
  };
}

export function sanitizeEditor(input: unknown): EditorState {
  const base = emptyEditor();
  const raw = typeof input === "string" ? parseJson(input) : input;
  if (!raw || typeof raw !== "object") return base;
  const o = raw as Record<string, unknown>;

  const captions = Array.isArray(o.captions) ? o.captions.slice(0, 400).map(sanitizeCaption).filter((c): c is Caption => !!c) : [];
  const clips = Array.isArray(o.clips) ? o.clips.slice(0, 24).map(sanitizeClip).filter((c): c is Clip => !!c) : [];
  const effects = Array.isArray(o.effects) ? o.effects.slice(0, 80).map(sanitizeEffect).filter((e): e is Effect => !!e) : [];
  const music = Array.isArray(o.music) ? o.music.slice(0, 8).map(sanitizeMusic).filter((m): m is MusicSuggestion => !!m) : [];

  const styleRaw = o.captionStyle && typeof o.captionStyle === "object" ? (o.captionStyle as Record<string, unknown>) : {};
  const captionStyle: CaptionStyle = {
    font: FONTS.has(String(styleRaw.font)) ? (styleRaw.font as CaptionStyle["font"]) : "syne",
    color: COLORS.has(String(styleRaw.color)) ? (styleRaw.color as CaptionStyle["color"]) : "paper",
    effect: CAP_EFFECTS.has(String(styleRaw.effect)) ? (styleRaw.effect as CaptionStyle["effect"]) : "none",
    size: SIZES.has(String(styleRaw.size)) ? (styleRaw.size as CaptionStyle["size"]) : "md",
    position: POSITIONS.has(String(styleRaw.position)) ? (styleRaw.position as CaptionStyle["position"]) : "bottom",
  };

  let analysis: Analysis | null = null;
  if (o.analysis && typeof o.analysis === "object") {
    const a = o.analysis as Record<string, unknown>;
    const peaks = Array.isArray(a.peaks)
      ? a.peaks
          .slice(0, 200)
          .map((p) => {
            if (!p || typeof p !== "object") return null;
            const peak = p as Record<string, unknown>;
            const t = num(peak.t, NaN);
            const energy = num(peak.energy, NaN);
            if (!Number.isFinite(t) || !Number.isFinite(energy)) return null;
            return { t: Math.max(0, t), energy: Math.max(0, energy) };
          })
          .filter((p): p is { t: number; energy: number } => !!p)
      : [];
    analysis = { summary: str(a.summary, 500), peaks, aiRanked: a.aiRanked === true };
  }

  const active = typeof o.activeClipId === "string" ? o.activeClipId : null;

  return {
    captions,
    clips,
    effects,
    music,
    musicName: o.musicName == null ? null : str(o.musicName, 120) || null,
    captionStyle,
    grade: GRADES.has(String(o.grade)) ? (o.grade as Grade) : "cinematic",
    crop: CROPS.has(String(o.crop)) ? (o.crop as EditorState["crop"]) : "center",
    activeClipId: active && clips.some((c) => c.id === active) ? active : (clips[0]?.id ?? null),
    analysis,
  };
}

function parseJson(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}

function sanitizeCaption(value: unknown): Caption | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  const text = str(o.text, 240);
  const id = str(o.id, 80);
  if (!text && !id) return null;
  const start = Math.max(0, num(o.start));
  const end = Math.max(start + 0.2, num(o.end, start + 1));
  const words = Array.isArray(o.words)
    ? o.words.slice(0, 40).flatMap((w) => {
        if (!w || typeof w !== "object") return [];
        const word = w as Record<string, unknown>;
        const t = str(word.text, 40);
        if (!t) return [];
        const ws = num(word.start, start);
        const we = Math.max(ws, num(word.end, ws + 0.2));
        return [{ text: t, start: ws, end: we }];
      })
    : [];
  const timing = o.timing === "words" || o.timing === "estimated" || o.timing === "manual" ? o.timing : "manual";
  return {
    id: str(o.id, 80) || crypto.randomUUID(),
    start,
    end,
    text,
    words,
    timing,
  };
}

function sanitizeClip(value: unknown): Clip | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  const start = Math.max(0, num(o.start));
  const end = num(o.end, start + 3);
  if (end <= start) return null;
  return {
    id: str(o.id, 80) || crypto.randomUUID(),
    start,
    end,
    title: str(o.title, 80) || "Clip",
    reason: str(o.reason, 280),
    score: Math.min(1, Math.max(0, num(o.score))),
    platform: PLATFORMS.has(String(o.platform)) ? (o.platform as Clip["platform"]) : "tiktok",
    source: o.source === "ai" ? "ai" : "energy",
  };
}

function sanitizeEffect(value: unknown): Effect | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  if (!EFFECT_TYPES.has(String(o.type))) return null;
  const start = Math.max(0, num(o.start));
  const end = Math.max(start + 0.05, num(o.end, start + 0.4));
  return {
    id: str(o.id, 80) || crypto.randomUUID(),
    type: o.type as EffectType,
    start,
    end,
    intensity: Math.min(1, Math.max(0.05, num(o.intensity, 0.6))),
  };
}

function sanitizeMusic(value: unknown): MusicSuggestion | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  const search = str(o.search, 140);
  if (!search) return null;
  return {
    id: str(o.id, 80) || crypto.randomUUID(),
    mood: str(o.mood, 40) || "match",
    bpm: Math.min(220, Math.max(40, Math.round(num(o.bpm, 120)))),
    search,
    why: str(o.why, 240),
  };
}
