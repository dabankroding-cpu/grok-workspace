import { createFileRoute, Link } from "@tanstack/react-router";
import { AudioLines, Captions, Clapperboard, Ratio, Scissors, Wand2 } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { PlanCards } from "@/components/plan-cards";
import { buttonClass } from "@/components/ui/button";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useAccount } from "@/lib/use-account";
import { TEMPLATES } from "@/lib/templates-data";

export const Route = createFileRoute("/")({
  component: Home,
});

const tools = [
  {
    icon: Scissors,
    title: "Moments",
    body: "Loudness is measured on your device. Grok can then rank those peaks using a few frames, not a made-up highlight reel.",
  },
  {
    icon: Captions,
    title: "Captions",
    body: "A short WAV of the range you choose goes to speech-to-text. Word times land on the frame when the API returns them.",
  },
  {
    icon: Wand2,
    title: "Effects",
    body: "Zoom, shake, flash, blur, and grades are drawn on the preview canvas and recorded into the export.",
  },
  {
    icon: Ratio,
    title: "Vertical export",
    body: "The cut is recorded in the browser as a 9:16 WebM. A 20 second clip takes about 20 seconds.",
  },
  {
    icon: AudioLines,
    title: "Music searches",
    body: "Grok suggests library searches for the edit. It does not host tracks. Upload audio you have rights to.",
  },
  {
    icon: Clapperboard,
    title: "Templates",
    body: "Cinematic and gaming are free. NBA, anime, and phonk swap the grade, type, and effect pattern.",
  },
];

function Home() {
  const { user, isPending } = useCurrentUserState();
  const { account, loading, reload } = useAccount(user?.id);

  return (
    <div className="min-h-dvh bg-bg">
      <SiteHeader />
      <main>
        <section className="border-b border-line">
          <div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 py-16 md:grid-cols-[1.15fr_0.85fr] md:py-24">
            <div>
              <p className="text-sm font-medium text-accent-bright">Video studio</p>
              <h1 className="mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight md:text-6xl">
                Find the moment. Caption it. Export 9:16.
              </h1>
              <p className="mt-5 max-w-xl text-lg text-muted">
                ClipForge reads the soundtrack on this device, can ask Grok to rank the peaks and transcribe a range, then records a vertical file from the preview you actually see.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                {isPending ? <span className="h-11 w-36 rounded-md bg-surface-2 motion-safe:animate-pulse" /> : null}
                {!isPending && user ? (
                  <Link to="/dashboard" className={buttonClass()}>
                    Open studio
                  </Link>
                ) : null}
                {!isPending && !user ? (
                  <Link to="/login" className={buttonClass()}>
                    Start free
                  </Link>
                ) : null}
                <Link to="/templates" className={buttonClass({ variant: "secondary" })}>
                  Browse templates
                </Link>
              </div>
            </div>
            <div className="mx-auto w-full max-w-xs rounded-2xl border border-line bg-surface p-4">
              <div className="flex aspect-[9/16] flex-col justify-between rounded-xl bg-bg p-4">
                <p className="font-mono text-xs text-subtle">9:16 frame</p>
                <div>
                  <p className="font-display text-2xl font-semibold leading-tight">Your footage renders here.</p>
                  <p className="mt-3 text-sm text-muted">Captions, crop, and grades are painted on the canvas, then recorded.</p>
                </div>
                <div className="space-y-2">
                  <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
                    <div className="h-full w-2/5 bg-accent" />
                  </div>
                  <p className="font-mono text-xs tabular-nums text-muted">0:08 / 0:20</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="tools" className="mx-auto w-full max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl font-semibold tracking-tight">What the studio actually does</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {tools.map((tool) => {
              const Icon = tool.icon;
              return (
                <article key={tool.title} className="rounded-2xl border border-line bg-surface p-4">
                  <Icon className="size-5 text-accent-bright" aria-hidden="true" />
                  <h3 className="mt-4 font-display text-xl font-semibold">{tool.title}</h3>
                  <p className="mt-2 text-sm text-muted">{tool.body}</p>
                </article>
              );
            })}
          </div>
        </section>

        <section className="border-y border-line">
          <div className="mx-auto w-full max-w-6xl px-4 py-16">
            <h2 className="font-display text-3xl font-semibold tracking-tight">Three steps</h2>
            <ol className="mt-8 grid gap-4 md:grid-cols-3">
              {[
                ["01", "Upload", "MP4 or WebM, under 8 minutes and 120 MB. The file stays in this browser."],
                ["02", "Mark", "Measure peaks locally, then optionally rank them and transcribe a range."],
                ["03", "Export", "Record the 9:16 preview as WebM. Free exports stop at 20 seconds."],
              ].map(([index, title, body]) => (
                <li key={index} className="rounded-2xl border border-line p-4">
                  <p className="font-mono text-sm text-accent-bright">{index}</p>
                  <h3 className="mt-3 font-display text-xl font-semibold">{title}</h3>
                  <p className="mt-2 text-sm text-muted">{body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-4 py-16">
          <div className="flex items-end justify-between gap-4">
            <h2 className="font-display text-3xl font-semibold tracking-tight">Templates</h2>
            <Link to="/templates" className="text-sm text-accent-bright">
              See the library
            </Link>
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {TEMPLATES.map((template) => (
              <article key={template.id} className="rounded-2xl border border-line bg-surface p-4">
                <p className="text-xs text-muted">{template.tier === "free" ? "Free" : "Pro trial"}</p>
                <h3 className="mt-2 font-display text-lg font-semibold">{template.name}</h3>
                <p className="mt-2 text-sm text-muted">{template.blurb}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="border-t border-line">
          <div className="mx-auto w-full max-w-6xl px-4 py-16">
            <h2 className="font-display text-3xl font-semibold tracking-tight">Free, and a trial that does not charge</h2>
            <p className="mt-3 max-w-2xl text-muted">
              Card billing is not connected. Pro limits are available as one 7-day trial per account.
            </p>
            <div className="mt-8">
              <PlanCards account={account} loading={isPending || (!!user && loading)} signedIn={!!user} onChanged={reload} />
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
